-- =====================================================================
-- Festipote : MODE SOIRÉE (événements + tableau de bord organisateur)
-- À coller dans Supabase > SQL Editor > New query, puis « Run ».
-- (Après supabase_setup.sql et supabase_duels.sql. Relançable sans risque.)
-- =====================================================================

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),   -- sert aussi d'identifiant Bluetooth
  name text not null,
  join_code text unique not null,                  -- code / QR affiché à l'entrée
  admin_code text not null,                        -- code secret de l'orga
  created_at timestamptz not null default now(),
  is_active boolean not null default true,
  duels_paused boolean not null default false,
  rssi_threshold int not null default -65,         -- distance (plus haut = plus près)
  dwell_seconds int not null default 20,           -- temps à rester près de quelqu'un
  pair_cooldown_min int not null default 45,       -- même paire : 1 duel max toutes les X min
  user_cooldown_min int not null default 8,        -- chaque personne : 1 duel max toutes les X min
  duel_window_sec int not null default 60,         -- durée pour appuyer
  next_num int not null default 0
);

create table if not exists public.event_members (
  event_id uuid not null references public.events on delete cascade,
  user_id uuid not null references public.profiles on delete cascade,
  num int not null,                                -- numéro diffusé en Bluetooth
  joined_at timestamptz not null default now(),
  primary key (event_id, user_id),
  unique (event_id, num)
);

alter table public.duels add column if not exists event_id uuid
  references public.events on delete set null;
create index if not exists duels_event_idx on public.duels (event_id, created_at);

-- Aucun accès direct : tout passe par les fonctions ci-dessous
alter table public.events enable row level security;
alter table public.event_members enable row level security;
revoke all on public.events from anon, authenticated;
revoke all on public.event_members from anon, authenticated;

-- ---------------------------------------------------------------------
-- Fonctions internes
-- ---------------------------------------------------------------------
create or replace function public._event_state(p_event uuid, p_me uuid)
returns json
language sql stable security definer set search_path = public
as $$
  select json_build_object(
    'id', e.id, 'name', e.name, 'join_code', e.join_code,
    'active', e.is_active, 'paused', e.duels_paused,
    'rssi_threshold', e.rssi_threshold, 'dwell_seconds', e.dwell_seconds,
    'pair_cooldown_min', e.pair_cooldown_min, 'user_cooldown_min', e.user_cooldown_min,
    'duel_window_sec', e.duel_window_sec,
    'me', (select m.num from public.event_members m where m.event_id = e.id and m.user_id = p_me),
    'members', coalesce((
      select json_agg(json_build_object('num', m.num, 'user_id', m.user_id, 'name', p.name) order by m.num)
      from public.event_members m join public.profiles p on p.id = m.user_id
      where m.event_id = e.id), '[]'::json)
  )
  from public.events e where e.id = p_event;
$$;

create or replace function public._event_board(p_event uuid)
returns table (user_id uuid, name text, wins bigint, losses bigint, draws bigint,
               best_ms integer, avg_ms integer, encounters bigint)
language sql stable security definer set search_path = public
as $$
  select m.user_id, p.name,
    (select count(*) from public.duels d where d.event_id = p_event and d.winner = m.user_id),
    (select count(*) from public.duels d where d.event_id = p_event and d.winner is not null
       and d.winner <> m.user_id and m.user_id in (d.player_a, d.player_b)),
    (select count(*) from public.duels d where d.event_id = p_event and d.winner is null
       and d.expires_at < now() and m.user_id in (d.player_a, d.player_b)),
    (select (min(extract(epoch from d.won_at - d.created_at)) * 1000)::integer
       from public.duels d where d.event_id = p_event and d.winner = m.user_id),
    (select (avg(extract(epoch from d.won_at - d.created_at)) * 1000)::integer
       from public.duels d where d.event_id = p_event and d.winner = m.user_id),
    (select count(*) from public.duels d where d.event_id = p_event
       and m.user_id in (d.player_a, d.player_b))   -- nombre de duels joués
  from public.event_members m join public.profiles p on p.id = m.user_id
  where m.event_id = p_event
  order by 3 desc, 6 asc nulls last, 2;
$$;

-- ---------------------------------------------------------------------
-- Organisateur (tableau de bord) : protégé par le code organisateur
-- ---------------------------------------------------------------------
create or replace function public.event_create(p_name text, p_preset text default 'petite')
returns json
language plpgsql security definer set search_path = public
as $$
declare
  alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  code text;
  ev public.events;
  i int;
begin
  if coalesce(trim(p_name), '') = '' then
    raise exception 'nom manquant';
  end if;
  loop
    code := '';
    for i in 1..6 loop
      code := code || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
    end loop;
    exit when not exists (select 1 from public.events where join_code = code);
  end loop;

  insert into public.events (name, join_code, admin_code)
  values (left(trim(p_name), 60), code, replace(gen_random_uuid()::text, '-', ''))
  returning * into ev;

  -- Réglages de départ selon le lieu
  if p_preset = 'moyenne' then
    update public.events set rssi_threshold = -72, dwell_seconds = 12, pair_cooldown_min = 30,
      user_cooldown_min = 5, duel_window_sec = 90 where id = ev.id;
  elsif p_preset = 'grande' then
    update public.events set rssi_threshold = -80, dwell_seconds = 5, pair_cooldown_min = 20,
      user_cooldown_min = 3, duel_window_sec = 120 where id = ev.id;
  end if;

  return json_build_object('join_code', ev.join_code, 'admin_code', ev.admin_code);
end;
$$;

create or replace function public.event_update(p_code text, p_admin text, p_changes json)
returns void
language plpgsql security definer set search_path = public
as $$
declare
  ev public.events;
begin
  select * into ev from public.events
  where join_code = upper(trim(p_code)) and admin_code = trim(p_admin);
  if not found then
    raise exception 'code organisateur invalide';
  end if;
  update public.events set
    name = coalesce(nullif(left(trim(p_changes->>'name'), 60), ''), name),
    duels_paused = coalesce((p_changes->>'duels_paused')::boolean, duels_paused),
    is_active = coalesce((p_changes->>'is_active')::boolean, is_active),
    rssi_threshold = greatest(-95, least(-40, coalesce((p_changes->>'rssi_threshold')::int, rssi_threshold))),
    dwell_seconds = greatest(0, least(300, coalesce((p_changes->>'dwell_seconds')::int, dwell_seconds))),
    pair_cooldown_min = greatest(1, least(600, coalesce((p_changes->>'pair_cooldown_min')::int, pair_cooldown_min))),
    user_cooldown_min = greatest(0, least(120, coalesce((p_changes->>'user_cooldown_min')::int, user_cooldown_min))),
    duel_window_sec = greatest(10, least(600, coalesce((p_changes->>'duel_window_sec')::int, duel_window_sec)))
  where id = ev.id;
end;
$$;

create or replace function public.event_dashboard(p_code text, p_admin text)
returns json
language plpgsql stable security definer set search_path = public
as $$
declare
  ev public.events;
begin
  select * into ev from public.events
  where join_code = upper(trim(p_code)) and admin_code = trim(p_admin);
  if not found then
    raise exception 'code organisateur invalide';
  end if;

  return json_build_object(
    'event', json_build_object(
      'name', ev.name, 'join_code', ev.join_code, 'created_at', ev.created_at,
      'active', ev.is_active, 'paused', ev.duels_paused,
      'rssi_threshold', ev.rssi_threshold, 'dwell_seconds', ev.dwell_seconds,
      'pair_cooldown_min', ev.pair_cooldown_min, 'user_cooldown_min', ev.user_cooldown_min,
      'duel_window_sec', ev.duel_window_sec),
    'stats', (
      select json_build_object(
        'members', (select count(*) from public.event_members m where m.event_id = ev.id),
        'duels', count(*),
        'won', count(*) filter (where d.winner is not null),
        'live', count(*) filter (where d.winner is null and d.expires_at > now()),
        'draws', count(*) filter (where d.winner is null and d.expires_at <= now()),
        'avg_ms', (avg(extract(epoch from d.won_at - d.created_at)) * 1000)::integer)
      from public.duels d where d.event_id = ev.id),
    'fastest', (
      select json_build_object('name', p.name,
        'ms', (extract(epoch from d.won_at - d.created_at) * 1000)::integer)
      from public.duels d join public.profiles p on p.id = d.winner
      where d.event_id = ev.id and d.winner is not null
      order by d.won_at - d.created_at limit 1),
    'rivalry', (
      select json_build_object('a', pa.name, 'b', pb.name, 'n', x.n)
      from (select least(player_a, player_b) a, greatest(player_a, player_b) b, count(*) n
            from public.duels where event_id = ev.id group by 1, 2 order by 3 desc limit 1) x
      join public.profiles pa on pa.id = x.a
      join public.profiles pb on pb.id = x.b
      where x.n > 1),
    'leaderboard', coalesce((
      select json_agg(json_build_object('name', b.name, 'wins', b.wins, 'losses', b.losses,
                                        'best_ms', b.best_ms, 'duels', b.encounters))
      from (select * from public._event_board(ev.id) limit 12) b), '[]'::json),
    'feed', coalesce((
      select json_agg(f order by f.id desc) from (
        select d.id, pa.name as a, pb.name as b, pw.name as winner,
          (extract(epoch from d.won_at - d.created_at) * 1000)::integer as ms,
          d.created_at,
          case when d.winner is not null then 'won'
               when d.expires_at > now() then 'live' else 'draw' end as state
        from public.duels d
        join public.profiles pa on pa.id = d.player_a
        join public.profiles pb on pb.id = d.player_b
        left join public.profiles pw on pw.id = d.winner
        where d.event_id = ev.id
        order by d.id desc limit 15) f), '[]'::json),
    'timeline', (
      select json_agg(json_build_object('t', b,
        'n', (select count(*) from public.duels d where d.event_id = ev.id
              and d.created_at >= b and d.created_at < b + interval '10 minutes')) order by b)
      from generate_series(date_bin('10 minutes', now() - interval '170 minutes', timestamptz '2000-01-01'),
                           now(), interval '10 minutes') b)
  );
end;
$$;

-- ---------------------------------------------------------------------
-- Participants (appli)
-- ---------------------------------------------------------------------
create or replace function public.event_join(p_code text)
returns json
language plpgsql security definer set search_path = public
as $$
declare
  me uuid := auth.uid();
  ev public.events;
  n int;
begin
  if me is null or not exists (select 1 from public.profiles where id = me) then
    raise exception 'profil manquant';
  end if;
  select * into ev from public.events where join_code = upper(trim(p_code));
  if not found or not ev.is_active then
    raise exception 'soirée introuvable';
  end if;
  select num into n from public.event_members where event_id = ev.id and user_id = me;
  if n is null then
    update public.events set next_num = next_num + 1 where id = ev.id returning next_num into n;
    insert into public.event_members (event_id, user_id, num) values (ev.id, me, n);
  end if;
  return public._event_state(ev.id, me);
end;
$$;

create or replace function public.event_sync(p_event uuid)
returns json
language plpgsql stable security definer set search_path = public
as $$
begin
  if not exists (select 1 from public.event_members
                 where event_id = p_event and user_id = auth.uid()) then
    return null;
  end if;
  return public._event_state(p_event, auth.uid());
end;
$$;

create or replace function public.event_leave(p_event uuid)
returns void
language sql security definer set search_path = public
as $$
  delete from public.event_members where event_id = p_event and user_id = auth.uid();
$$;

create or replace function public.event_leaderboard(p_event uuid)
returns table (user_id uuid, name text, wins bigint, losses bigint, draws bigint,
               best_ms integer, avg_ms integer, encounters bigint)
language sql stable security definer set search_path = public
as $$
  select * from public._event_board(p_event)
  where exists (select 1 from public.event_members m
                where m.event_id = p_event and m.user_id = auth.uid());
$$;

-- Lance un duel avec la personne portant le numéro p_num (règles anti-spam)
create or replace function public.event_duel_open(p_event uuid, p_num int)
returns setof public.duels
language plpgsql security definer set search_path = public
as $$
declare
  me uuid := auth.uid();
  other uuid;
  ev public.events;
  d public.duels;
begin
  select * into ev from public.events where id = p_event;
  if not found or not ev.is_active or ev.duels_paused then
    return;
  end if;
  if not exists (select 1 from public.event_members where event_id = p_event and user_id = me) then
    return;
  end if;
  select user_id into other from public.event_members where event_id = p_event and num = p_num;
  if other is null or other = me then
    return;
  end if;

  -- Verrous (toujours dans le même ordre) : pas deux duels à la fois pour la même personne
  perform pg_advisory_xact_lock(hashtextextended(least(me, other)::text, 0));
  perform pg_advisory_xact_lock(hashtextextended(greatest(me, other)::text, 0));

  update public.duels set is_open = false
  where is_open and expires_at < now()
    and (player_a in (me, other) or player_b in (me, other));

  -- Un duel est déjà en cours pour l'un des deux ?
  if exists (select 1 from public.duels
             where is_open and (player_a in (me, other) or player_b in (me, other))) then
    -- Si c'est entre nous deux, on le renvoie (l'autre l'a lancé en même temps)
    return query select * from public.duels
      where is_open and least(player_a, player_b) = least(me, other)
        and greatest(player_a, player_b) = greatest(me, other);
    return;
  end if;

  -- Même paire : pas avant le délai
  if exists (select 1 from public.duels
             where event_id = p_event
               and least(player_a, player_b) = least(me, other)
               and greatest(player_a, player_b) = greatest(me, other)
               and created_at > now() - make_interval(mins => ev.pair_cooldown_min)) then
    return;
  end if;
  -- Chacun des deux : pas avant le délai perso
  if exists (select 1 from public.duels
             where event_id = p_event
               and (player_a in (me, other) or player_b in (me, other))
               and created_at > now() - make_interval(mins => ev.user_cooldown_min)) then
    return;
  end if;

  insert into public.duels (player_a, player_b, event_id, expires_at)
  values (me, other, p_event, now() + make_interval(secs => ev.duel_window_sec))
  on conflict do nothing
  returning * into d;
  if found then
    return next d;
  end if;
end;
$$;

-- ---------------------------------------------------------------------
-- Droits
-- ---------------------------------------------------------------------
revoke execute on function public._event_state(uuid, uuid) from public, anon, authenticated;
revoke execute on function public._event_board(uuid) from public, anon, authenticated;

revoke execute on function public.event_create(text, text) from public;
revoke execute on function public.event_update(text, text, json) from public;
revoke execute on function public.event_dashboard(text, text) from public;
grant execute on function public.event_create(text, text) to anon, authenticated;
grant execute on function public.event_update(text, text, json) to anon, authenticated;
grant execute on function public.event_dashboard(text, text) to anon, authenticated;

revoke execute on function public.event_join(text) from public, anon;
revoke execute on function public.event_sync(uuid) from public, anon;
revoke execute on function public.event_leave(uuid) from public, anon;
revoke execute on function public.event_leaderboard(uuid) from public, anon;
revoke execute on function public.event_duel_open(uuid, int) from public, anon;
grant execute on function public.event_join(text) to authenticated;
grant execute on function public.event_sync(uuid) to authenticated;
grant execute on function public.event_leave(uuid) to authenticated;
grant execute on function public.event_leaderboard(uuid) to authenticated;
grant execute on function public.event_duel_open(uuid, int) to authenticated;
