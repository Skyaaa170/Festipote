-- =====================================================================
-- Festipote : à coller dans Supabase > SQL Editor > New query, puis « Run ».
-- On peut le relancer sans risque.
-- =====================================================================

-- Profils : un par téléphone (compte anonyme)
create table if not exists public.profiles (
  id uuid primary key references auth.users on delete cascade,
  ble_id uuid unique not null,
  name text not null default 'Pote',
  lat double precision,
  lon double precision,
  location_at timestamptz
);

-- Code d'invitation (dans le QR code). Jamais visible par les autres.
create table if not exists public.invites (
  user_id uuid primary key references public.profiles on delete cascade,
  code text not null
);

-- Amitiés (créées dans les deux sens quand on scanne un QR code)
create table if not exists public.friendships (
  user_id uuid not null references public.profiles on delete cascade,
  friend_id uuid not null references public.profiles on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, friend_id)
);

-- Messages du chat
create table if not exists public.messages (
  id bigint generated always as identity primary key,
  sender uuid not null default auth.uid() references public.profiles on delete cascade,
  recipient uuid not null references public.profiles on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index if not exists messages_sender_idx on public.messages (sender);
create index if not exists messages_recipient_idx on public.messages (recipient);

-- ---------------------------------------------------------------------
-- Sécurité : chacun ne voit que lui-même et ses potes
-- ---------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.invites enable row level security;
alter table public.friendships enable row level security;
alter table public.messages enable row level security;

drop policy if exists "profils visibles" on public.profiles;
create policy "profils visibles" on public.profiles for select to authenticated
  using (id = auth.uid() or exists (
    select 1 from public.friendships f
    where f.user_id = auth.uid() and f.friend_id = profiles.id));

drop policy if exists "creer mon profil" on public.profiles;
create policy "creer mon profil" on public.profiles for insert to authenticated
  with check (id = auth.uid());

drop policy if exists "modifier mon profil" on public.profiles;
create policy "modifier mon profil" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "mon code" on public.invites;
create policy "mon code" on public.invites for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "voir mes potes" on public.friendships;
create policy "voir mes potes" on public.friendships for select to authenticated
  using (user_id = auth.uid());

drop policy if exists "retirer un pote" on public.friendships;
create policy "retirer un pote" on public.friendships for delete to authenticated
  using (user_id = auth.uid() or friend_id = auth.uid());

drop policy if exists "lire mes messages" on public.messages;
create policy "lire mes messages" on public.messages for select to authenticated
  using (sender = auth.uid() or recipient = auth.uid());

drop policy if exists "ecrire a mes potes" on public.messages;
create policy "ecrire a mes potes" on public.messages for insert to authenticated
  with check (sender = auth.uid() and exists (
    select 1 from public.friendships f
    where f.user_id = auth.uid() and f.friend_id = recipient));

grant select, insert, update on public.profiles to authenticated;
grant select, insert, update, delete on public.invites to authenticated;
grant select, delete on public.friendships to authenticated;
grant select, insert on public.messages to authenticated;

-- ---------------------------------------------------------------------
-- Ajouter un pote : il faut son code d'invitation (dans son QR code)
-- ---------------------------------------------------------------------
create or replace function public.add_friend(p_ble_id uuid, p_code text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  target uuid;
begin
  select p.id into target
  from public.profiles p
  join public.invites i on i.user_id = p.id
  where p.ble_id = p_ble_id and i.code = p_code;

  if target is null then
    raise exception 'code invalide';
  end if;
  if target = auth.uid() then
    return;
  end if;

  insert into public.friendships (user_id, friend_id)
  values (auth.uid(), target), (target, auth.uid())
  on conflict do nothing;
end;
$$;

revoke execute on function public.add_friend(uuid, text) from public, anon;
grant execute on function public.add_friend(uuid, text) to authenticated;

-- ---------------------------------------------------------------------
-- Temps réel pour le chat
-- ---------------------------------------------------------------------
do $$
begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
end $$;
