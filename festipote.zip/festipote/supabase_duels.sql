-- =====================================================================
-- Festipote : DUELS + CLASSEMENT
-- À coller dans Supabase > SQL Editor > New query, puis « Run ».
-- (Après supabase_setup.sql. On peut le relancer sans risque.)
-- =====================================================================

-- Duels : créés quand deux potes se croisent, le premier qui appuie gagne
create table if not exists public.duels (
  id bigint generated always as identity primary key,
  player_a uuid not null references public.profiles on delete cascade, -- celui qui a lancé
  player_b uuid not null references public.profiles on delete cascade,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '3 minutes',
  is_open boolean not null default true,
  winner uuid references public.profiles on delete set null,
  won_at timestamptz,
  a_tapped_at timestamptz,
  b_tapped_at timestamptz
);
-- Un seul duel ouvert à la fois par paire de potes
create unique index if not exists duels_un_ouvert_par_paire
  on public.duels (least(player_a, player_b), greatest(player_a, player_b)) where is_open;
create index if not exists duels_player_a_idx on public.duels (player_a);
create index if not exists duels_player_b_idx on public.duels (player_b);

-- Croisements enregistrés en ligne (pour le classement)
create table if not exists public.encounters (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles on delete cascade,
  friend_id uuid not null references public.profiles on delete cascade,
  created_at timestamptz not null default now()
);
create index if not exists encounters_user_idx
  on public.encounters (user_id, friend_id, created_at desc);

alter table public.duels enable row level security;
alter table public.encounters enable row level security;

drop policy if exists "voir mes duels" on public.duels;
create policy "voir mes duels" on public.duels for select to authenticated
  using (player_a = auth.uid() or player_b = auth.uid());

drop policy if exists "voir mes croisements" on public.encounters;
create policy "voir mes croisements" on public.encounters for select to authenticated
  using (user_id = auth.uid());

-- Lecture seule : tout se modifie via les fonctions ci-dessous
grant select on public.duels to authenticated;
grant select on public.encounters to authenticated;

-- ---------------------------------------------------------------------
-- Lancer (ou retrouver) un duel avec un pote
-- ---------------------------------------------------------------------
create or replace function public.duel_open(p_friend uuid)
returns setof public.duels
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
  d public.duels;
begin
  if me is null then
    raise exception 'non connecté';
  end if;
  if not exists (select 1 from public.friendships f
                 where f.user_id = me and f.friend_id = p_friend) then
    raise exception 'pas ton pote';
  end if;

  -- On ferme les duels expirés de cette paire
  update public.duels set is_open = false
  where is_open and expires_at < now()
    and least(player_a, player_b) = least(me, p_friend)
    and greatest(player_a, player_b) = greatest(me, p_friend);

  -- Pas plus d'un duel toutes les 10 minutes par paire (anti-triche)
  select * into d from public.duels
  where least(player_a, player_b) = least(me, p_friend)
    and greatest(player_a, player_b) = greatest(me, p_friend)
    and created_at > now() - interval '10 minutes'
  order by created_at desc
  limit 1;
  if found then
    return next d;
    return;
  end if;

  insert into public.duels (player_a, player_b) values (me, p_friend)
  on conflict do nothing
  returning * into d;

  if not found then
    -- Ton pote l'a créé au même moment : on renvoie le sien
    select * into d from public.duels
    where is_open
      and least(player_a, player_b) = least(me, p_friend)
      and greatest(player_a, player_b) = greatest(me, p_friend)
    limit 1;
  end if;
  return next d;
end;
$$;

-- ---------------------------------------------------------------------
-- Appuyer sur le bouton : renvoie 'won', 'lost' ou 'expired'
-- ---------------------------------------------------------------------
create or replace function public.duel_tap(p_duel bigint)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
  d public.duels;
begin
  -- « for update » : si les deux appuient en même temps, un seul gagne
  select * into d from public.duels
  where id = p_duel and (player_a = me or player_b = me)
  for update;
  if not found then
    raise exception 'duel introuvable';
  end if;

  if d.player_a = me and d.a_tapped_at is null then
    update public.duels set a_tapped_at = now() where id = p_duel;
  elsif d.player_b = me and d.b_tapped_at is null then
    update public.duels set b_tapped_at = now() where id = p_duel;
  end if;

  if d.winner is not null then
    return case when d.winner = me then 'won' else 'lost' end;
  end if;
  if now() > d.expires_at then
    update public.duels set is_open = false where id = p_duel;
    return 'expired';
  end if;

  update public.duels set winner = me, won_at = now(), is_open = false
  where id = p_duel;
  return 'won';
end;
$$;

-- ---------------------------------------------------------------------
-- Enregistrer un croisement (max 1 toutes les 9 minutes par pote)
-- ---------------------------------------------------------------------
create or replace function public.log_encounter(p_friend uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (select 1 from public.friendships f
                 where f.user_id = auth.uid() and f.friend_id = p_friend) then
    return;
  end if;
  if exists (select 1 from public.encounters e
             where e.user_id = auth.uid() and e.friend_id = p_friend
               and e.created_at > now() - interval '9 minutes') then
    return;
  end if;
  insert into public.encounters (user_id, friend_id) values (auth.uid(), p_friend);
end;
$$;

-- ---------------------------------------------------------------------
-- Classement : toi + tes potes
-- ---------------------------------------------------------------------
create or replace function public.leaderboard()
returns table (
  user_id uuid,
  name text,
  wins bigint,
  losses bigint,
  draws bigint,
  best_ms integer,
  avg_ms integer,
  encounters bigint
)
language sql
stable
security definer
set search_path = public
as $$
  with cercle as (
    select auth.uid() as id
    union
    select f.friend_id from public.friendships f where f.user_id = auth.uid()
  )
  select
    p.id,
    p.name,
    (select count(*) from public.duels d where d.winner = p.id),
    (select count(*) from public.duels d
      where d.winner is not null and d.winner <> p.id and p.id in (d.player_a, d.player_b)),
    (select count(*) from public.duels d
      where d.winner is null and d.expires_at < now() and p.id in (d.player_a, d.player_b)),
    (select (min(extract(epoch from d.won_at - d.created_at)) * 1000)::integer
      from public.duels d where d.winner = p.id),
    (select (avg(extract(epoch from d.won_at - d.created_at)) * 1000)::integer
      from public.duels d where d.winner = p.id),
    (select count(*) from public.encounters e where e.user_id = p.id)
  from cercle c
  join public.profiles p on p.id = c.id
  where c.id is not null
  order by 3 desc, 6 asc nulls last, 2;
$$;

revoke execute on function public.duel_open(uuid) from public, anon;
revoke execute on function public.duel_tap(bigint) from public, anon;
revoke execute on function public.log_encounter(uuid) from public, anon;
revoke execute on function public.leaderboard() from public, anon;
grant execute on function public.duel_open(uuid) to authenticated;
grant execute on function public.duel_tap(bigint) to authenticated;
grant execute on function public.log_encounter(uuid) to authenticated;
grant execute on function public.leaderboard() to authenticated;

-- Temps réel : ton pote voit le duel apparaître et le résultat en direct
do $$
begin
  alter publication supabase_realtime add table public.duels;
exception when duplicate_object then null;
end $$;
