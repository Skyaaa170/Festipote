# Festipote

Ton téléphone vibre quand tu croises un pote en festival. Ça marche **sans réseau** grâce au Bluetooth Low Energy : rien ne passe par Internet, tout reste sur les téléphones.

## Comment ça marche

1. Au premier lancement, chaque téléphone reçoit un identifiant aléatoire.
2. Tu ajoutes tes potes en scannant leur QR code dans l'appli.
3. En « mode festival », ton téléphone diffuse ton identifiant en Bluetooth et écoute ceux de tes potes. Quand le signal d'un pote est assez fort (donc qu'il est proche), ça vibre. Une seule alerte par pote toutes les 10 minutes.

Pour être prévenu quand tu croises quelqu'un, c'est toi qui dois avoir scanné son QR code. Pour que ça marche dans les deux sens, scannez-vous mutuellement.

## Les onglets

- **Radar** : le mode festival, ton téléphone vibre quand un pote passe près de toi (Bluetooth, sans réseau).
- **Carte** : la position des potes qui la partagent (réseau nécessaire). Le partage est désactivé par défaut. Quand il est activé, une notification permanente l'indique.
- **Chat** : discussions avec chacun de tes potes (réseau nécessaire).
- **Duels** : quand tu croises un pote, ça vibre et un duel se lance. Le premier qui ouvre l'appli et appuie sur le bouton gagne. Classement entre potes, historique, records de réaction (réseau nécessaire).
- **Stats** : nombre de croisements, potes les plus croisés, heures de croisement. Tout reste sur le téléphone.

## Serveur (pour la carte et le chat)

Gratuit avec Supabase, à faire une seule fois :

1. Crée un compte sur supabase.com, puis un projet (« New project », région Europe).
2. Dans **SQL Editor** → **New query**, colle tout le fichier `supabase_setup.sql` et appuie sur **Run**. Fais pareil ensuite avec `supabase_duels.sql` (duels et classement).
3. Dans **Authentication** → **Sign In / Providers**, active **Allow anonymous sign-ins** et enregistre.
4. Dans les réglages du projet, section **API Keys** (ou « Data API »), copie l'**URL du projet** (https://xxxx.supabase.co) et la clé **publique** (« anon » ou « publishable »). Ne prends **jamais** la clé « service_role » ou « secret ».
5. Sur GitHub, à la racine du dépôt : « Add file » → « Create new file », nommé `supabase.txt`, avec l'URL sur la première ligne et la clé sur la deuxième.

La prochaine compilation intègre automatiquement le serveur. Sans ce fichier, la carte et le chat sont simplement désactivés.

Sécurité : chacun ne voit que les potes qui l'ont ajouté avec son QR code (ou son code copié). Quelqu'un qui capte ton signal Bluetooth ne peut ni voir ta position ni t'écrire.

## Obtenir l'APK sans ordinateur (GitHub compile pour toi)

1. Crée un compte sur github.com, puis un nouveau dépôt (bouton « New repository »).
2. Dans le dépôt : « Add file » → « Upload files » → envoie `festipote.zip` tel quel → « Commit changes ».
3. « Add file » → « Create new file ». Nom du fichier : `.github/workflows/build-apk.yml`. Colle dedans le contenu du fichier `build-apk.yml` → « Commit changes ».
4. La compilation démarre toute seule (onglet « Actions », 5 à 10 minutes).
5. Quand c'est vert, va dans « Releases » sur la page du dépôt et télécharge `festipote.apk`. Android te demandera d'autoriser l'installation d'applis de sources inconnues.

Si c'est rouge dans « Actions », ouvre l'étape en erreur et copie le message pour corriger.

## Installation avec un ordinateur

Il te faut [Flutter](https://docs.flutter.dev/get-started/install) et un vrai téléphone (le Bluetooth ne marche pas sur simulateur). Pour iPhone, il faut un Mac avec Xcode.

**1. Créer le projet**

```bash
flutter create festipote
cd festipote
```

Remplace `pubspec.yaml` et le dossier `lib/` par ceux de ce zip, puis supprime `test/widget_test.dart`.

```bash
flutter pub get
```

Si une version de paquet pose problème, `flutter pub add nom_du_paquet` prend la dernière version compatible.

**2. Android : permissions**

Dans `android/app/src/main/AndroidManifest.xml`, colle ceci juste avant la ligne `<application` :

```xml
<!-- Android 12 et plus -->
<uses-permission android:name="android.permission.BLUETOOTH_SCAN"
    android:usesPermissionFlags="neverForLocation" />
<uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE" />
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
<!-- Android 11 et moins -->
<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30" />
<!-- Autres -->
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.VIBRATE" />
<uses-feature android:name="android.hardware.bluetooth_le" android:required="true" />
```

**3. Android : réglage de compilation** (demandé par le paquet de notifications)

Dans `android/app/build.gradle.kts`, ajoute dans le bloc `android { ... }` :

```kotlin
compileOptions {
    isCoreLibraryDesugaringEnabled = true
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}
```

(s'il y a déjà un bloc `compileOptions`, ajoute juste la première ligne dedans), et à la fin du fichier :

```kotlin
dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
```

**4. iPhone : autorisations et arrière-plan**

Dans `ios/Runner/Info.plist`, colle ceci juste avant le dernier `</dict>` :

```xml
<key>NSBluetoothAlwaysUsageDescription</key>
<string>Festipote utilise le Bluetooth pour savoir quand tes potes sont à proximité.</string>
<key>NSCameraUsageDescription</key>
<string>Pour scanner le QR code de tes potes.</string>
<key>UIBackgroundModes</key>
<array>
    <string>bluetooth-central</string>
    <string>bluetooth-peripheral</string>
</array>
```

**5. Lancer**

Branche ton téléphone et lance :

```bash
flutter run
```

## Limites à connaître

- Tout le monde doit avoir l'appli avec le mode festival activé.
- **iPhone** : ne ferme pas l'appli en la balayant dans le multitâche, sinon elle s'arrête. Écran verrouillé, ça marche.
- **iPhone ↔ Android** : quand l'appli d'un iPhone est en arrière-plan, Apple masque son signal aux téléphones Android. Un Android ne détecte donc un iPhone que si l'appli est ouverte à l'écran. iPhone ↔ iPhone et Android ↔ Android fonctionnent écran verrouillé. Un iPhone qui en capte un autre en arrière-plan sait qu'un pote est là mais pas lequel, d'où l'alerte « Un·e de tes potes est dans le coin ».
- **Android** : certaines marques (Xiaomi, Samsung, Huawei, Oppo…) coupent les applis en arrière-plan pour économiser la batterie. Dans les réglages du téléphone, désactive l'optimisation de batterie pour Festipote.
- La distance est approximative : les corps absorbent beaucoup le Bluetooth, donc dans une foule dense la portée baisse nettement. Le réglage « Large » compense.
- Batterie : la consommation est modérée, mais prévois une batterie externe.
- Vie privée : ton identifiant est fixe, donc quelqu'un qui l'a pourrait savoir quand tu es proche. Entre potes, ça va ; pour une version publique, il faudrait des identifiants qui changent régulièrement.

## Pistes pour la suite

- Un « service de premier plan » Android (paquet `flutter_foreground_task`) pour un fonctionnement garanti écran éteint, même sur les marques agressives.
- Un QR code de groupe pour ajouter tout le collectif d'un coup.
- Des identifiants tournants pour la vie privée.
