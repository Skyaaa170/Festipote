"""Réglages Android appliqués après `flutter create` (lancé par GitHub Actions)."""
import base64
import json
import os
import pathlib
import re
import subprocess

SDK = 36

# --- Permissions Bluetooth, caméra, notifications ---------------------------
m = pathlib.Path('android/app/src/main/AndroidManifest.xml')
s = m.read_text()
perms = '''<uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-feature android:name="android.hardware.bluetooth_le" android:required="true" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    '''
if 'BLUETOOTH_SCAN' not in s:
    s = s.replace('<application', perms + '<application', 1)
    s = s.replace('android:label="festipote"', 'android:label="Festipote"', 1)
    m.write_text(s)

# --- build.gradle de l'appli -------------------------------------------------
kts = pathlib.Path('android/app/build.gradle.kts')
is_kts = kts.exists()
g = kts if is_kts else pathlib.Path('android/app/build.gradle')
s = g.read_text()

if is_kts:
    desugar_flag = 'isCoreLibraryDesugaringEnabled = true'
    desugar_dep = 'coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")'
    no_r8 = 'release {\n            isMinifyEnabled = false\n            isShrinkResources = false\n        }'
    s = s.replace('compileSdk = flutter.compileSdkVersion',
                  f'compileSdk = maxOf(flutter.compileSdkVersion, {SDK})')
else:
    desugar_flag = 'coreLibraryDesugaringEnabled true'
    desugar_dep = "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'"
    no_r8 = 'release {\n            minifyEnabled false\n            shrinkResources false\n        }'
    s = re.sub(r'compileSdk(?:Version)? flutter\.compileSdkVersion',
               f'compileSdk Math.max(flutter.compileSdkVersion, {SDK})', s)

# Desugaring (demandé par flutter_local_notifications)
if 'DesugaringEnabled' not in s:
    if 'compileOptions {' in s:
        s = s.replace('compileOptions {', 'compileOptions {\n        ' + desugar_flag, 1)
    else:
        s = s.replace('android {', 'android {\n    compileOptions {\n        ' + desugar_flag + '\n    }', 1)
    s += '\ndependencies {\n    ' + desugar_dep + '\n}\n'

# Pas de R8 : il casse souvent la caméra / ML Kit dans les APK finaux
if 'MinifyEnabled = false' not in s and 'minifyEnabled false' not in s:
    if 'buildTypes {' in s:
        s = s.replace('buildTypes {', 'buildTypes {\n        ' + no_r8, 1)
    else:
        s = s.replace('android {', 'android {\n    buildTypes {\n        ' + no_r8 + '\n    }', 1)

# Clé de signature fixe : sans elle, chaque APK a une signature différente
# et Android refuse de mettre à jour l'appli sans la désinstaller.
repo = pathlib.Path('..').resolve() if pathlib.Path('../.git').exists() else pathlib.Path('.').resolve()
ks = repo / 'festipote-signature.jks'
if not ks.exists():
    subprocess.run(['keytool', '-genkeypair', '-keystore', str(ks), '-storetype', 'PKCS12',
                    '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000',
                    '-alias', 'festipote', '-storepass', 'festipote', '-keypass', 'festipote',
                    '-dname', 'CN=Festipote, O=Festipote, C=FR'], check=True)
    branch = os.environ.get('GITHUB_REF_NAME', 'main')
    git = ['git', '-C', str(repo)]
    try:
        subprocess.run(git + ['config', 'user.name', 'festipote-bot'], check=True)
        subprocess.run(git + ['config', 'user.email', 'festipote-bot@users.noreply.github.com'], check=True)
        subprocess.run(git + ['add', ks.name], check=True)
        subprocess.run(git + ['commit', '-m', 'Clé de signature Festipote (automatique)'], check=True)
        subprocess.run(git + ['pull', '--rebase', 'origin', branch], check=False)
        subprocess.run(git + ['push', 'origin', 'HEAD:' + branch], check=True)
        print('Clé de signature créée et enregistrée dans le dépôt')
    except Exception as e:
        print('::warning::Clé de signature non enregistrée dans le dépôt :', e)
else:
    print('Clé de signature existante réutilisée')

store_path = json.dumps(str(ks))
if is_kts:
    signing = ('signingConfigs {\n        create("festipote") {\n'
               f'            storeFile = file({store_path})\n'
               '            storePassword = "festipote"\n            keyAlias = "festipote"\n'
               '            keyPassword = "festipote"\n        }\n    }\n')
    use = 'signingConfig = signingConfigs.getByName("festipote")'
    s = s.replace('signingConfig = signingConfigs.getByName("debug")', use)
    anchor = 'isShrinkResources = false'
else:
    signing = ('signingConfigs {\n        festipote {\n'
               f'            storeFile file({store_path})\n'
               "            storePassword 'festipote'\n            keyAlias 'festipote'\n"
               "            keyPassword 'festipote'\n        }\n    }\n")
    use = 'signingConfig signingConfigs.festipote'
    s = re.sub(r'signingConfig\s*=?\s*signingConfigs\.debug', use, s)
    anchor = 'shrinkResources false'
if 'signingConfigs {' not in s:
    s = s.replace('android {', 'android {\n    ' + signing, 1)
if use not in s:
    s = s.replace(anchor, anchor + '\n            ' + use, 1)

# Numéro de version = numéro de compilation GitHub (toujours croissant)
run = os.environ.get('GITHUB_RUN_NUMBER')
if run:
    pub = pathlib.Path('pubspec.yaml')
    pub.write_text(re.sub(r'^version:.*$', f'version: 1.0.{run}+{run}', pub.read_text(), count=1, flags=re.M))
    pathlib.Path('lib/build_info.dart').write_text(f"const appBuild = '{run}';\n")
    print('Version :', run)

g.write_text(s)
print('Réglages Android OK')
print('\n'.join(l for l in s.splitlines() if re.search(r'compileSdk|inify|hrink|esugar', l)))

# --- Serveur Supabase (carte + chat) ----------------------------------------
# On lit supabase.txt (ou .json) à la racine du dépôt, en étant tolérant :
# URL du projet, lien du tableau de bord ou identifiant seul, + clé publique.
cfg_text = None
for name in ['../supabase.txt', '../supabase.json', 'supabase.txt', 'supabase.json',
             '../supabase.txt.txt', '../Supabase.txt']:
    path = pathlib.Path(name)
    if path.exists():
        cfg_text = path.read_text(errors='ignore')
        print('Fichier serveur lu :', path.name)
        break


def jwt_payload(token):
    try:
        part = token.split('.')[1]
        return json.loads(base64.urlsafe_b64decode(part + '=' * (-len(part) % 4)))
    except Exception:
        return {}


KEY_RE = r'sb_(?:publishable|secret)_[A-Za-z0-9_-]+|eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+'


def masked(line):
    # Affiche la ligne en masquant seulement ce qui ressemble à une clé
    return re.sub(KEY_RE, lambda m: m.group(0)[:15] + '…', line.strip())


config = pathlib.Path('lib/config.dart')
if cfg_text is None:
    print('::notice::Pas de supabase.txt : carte et chat désactivés dans cet APK.')
else:
    text = cfg_text.replace('\ufeff', '')
    key_m = re.search(r'sb_publishable_[A-Za-z0-9_-]+|eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+', text)
    key = key_m.group(0) if key_m else None
    payload = jwt_payload(key) if key and key.startswith('eyJ') else {}

    # Sécurité : jamais de clé secrète dans l'appli
    if 'sb_secret_' in text or payload.get('role') == 'service_role':
        print('::error::supabase.txt contient une clé SECRÈTE (service_role / sb_secret). '
              'Mets la clé publique (anon / publishable) à la place, et régénère la clé secrète dans Supabase.')
        raise SystemExit(1)

    # Identifiant du projet, trouvé de plusieurs façons
    ref = None
    for pattern in [r'([a-z0-9-]{6,})\.supabase\.(?:co|in)',   # https://xxxx.supabase.co
                    r'project/([a-z0-9]{6,})',                  # lien du tableau de bord
                    r'(?<![A-Za-z0-9_])([a-z]{20})(?![A-Za-z0-9_])']:  # identifiant seul
        m = re.search(pattern, text.replace(key, ' ') if key else text, re.I if 'supabase' in pattern or 'project' in pattern else 0)
        if m:
            ref = m.group(1).lower()
            break
    if ref is None and payload.get('ref'):
        ref = str(payload['ref'])                               # caché dans la clé anon
    url = f'https://{ref}.supabase.co' if ref else None

    if not url or not key:
        print('::error::supabase.txt : ' + ('adresse du projet introuvable. ' if not url else '')
              + ('clé publique introuvable (elle commence par sb_publishable_ ou eyJ). ' if not key else ''))
        print('Contenu lu (clés masquées) :')
        for line in text.splitlines():
            if line.strip():
                print('   ', masked(line))
        raise SystemExit(1)

    def dart(v):
        return json.dumps(v).replace('$', '\\$')
    config.write_text(
        '// Généré à la compilation depuis supabase.txt\n'
        f'const supabaseUrl = {dart(url)};\n'
        f'const supabaseKey = {dart(key)};\n')
    print('Serveur configuré :', url, '| clé', masked(key))
