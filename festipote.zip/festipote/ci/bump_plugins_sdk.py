"""Remonte le compileSdk des vieux paquets Flutter à 36 minimum (après `flutter pub get`)."""
import os
import pathlib
import re

SDK = 36
pat = re.compile(r'(compileSdk(?:Version)?\s*(?:=\s*|\(\s*)?)(\d+)')


def bump(match):
    return match.group(1) + str(max(int(match.group(2)), SDK))


cache = pathlib.Path(os.environ.get('PUB_CACHE') or pathlib.Path.home() / '.pub-cache')
files = list(cache.glob('hosted/*/*/android/build.gradle')) + \
    list(cache.glob('hosted/*/*/android/build.gradle.kts'))
for f in files:
    s = f.read_text()
    n = pat.sub(bump, s)
    if n != s:
        f.write_text(n)
        print('compileSdk relevé :', f.parent.parent.name)
