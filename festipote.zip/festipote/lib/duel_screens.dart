import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'cloud.dart';
import 'duel_models.dart';
import 'main.dart' show kRed;
import 'store.dart';

// =============================================================================
// L'écran du duel : un gros bouton, le premier qui appuie gagne
// =============================================================================

class DuelScreen extends StatefulWidget {
  const DuelScreen({super.key, required this.cloud, required this.duelId});

  final Cloud cloud;
  final int duelId;

  @override
  State<DuelScreen> createState() => _DuelScreenState();
}

class _DuelScreenState extends State<DuelScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 600),
  )..repeat(reverse: true);
  Timer? _tick;
  bool _tapping = false;
  String? _result; // réponse du serveur : won / lost / expired

  @override
  void initState() {
    super.initState();
    // Rafraîchit le compte à rebours
    _tick = Timer.periodic(const Duration(milliseconds: 250), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    _pulse.dispose();
    super.dispose();
  }

  Future<void> _tap() async {
    if (_tapping || _result != null) return;
    HapticFeedback.heavyImpact();
    setState(() => _tapping = true);
    final r = await widget.cloud.tapDuel(widget.duelId);
    if (!mounted) return;
    setState(() {
      _tapping = false;
      if (r != 'error') _result = r;
    });
    if (r == 'error') {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Pas de réseau… réappuie vite !'),
      ));
    } else if (r == 'won') {
      HapticFeedback.vibrate();
    }
  }

  @override
  Widget build(BuildContext context) {
    final cloud = widget.cloud;
    return ListenableBuilder(
      listenable: cloud,
      builder: (context, _) {
        final d = cloud.duelById(widget.duelId);
        final me = cloud.myServerId;
        if (d == null || me == null) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final oppName = cloud.nameOf(d.opponentOf(me));

        String? outcome = _result;
        if (d.winner != null) {
          outcome = d.winner == me ? 'won' : 'lost';
        } else if (outcome == null && d.remaining <= Duration.zero) {
          outcome = 'expired';
        }

        return Scaffold(
          backgroundColor: outcome == null ? kRed : Colors.black,
          body: SafeArea(
            child: outcome == null
                ? _pending(d, oppName)
                : _done(d, me, oppName, outcome),
          ),
        );
      },
    );
  }

  Widget _pending(Duel d, String oppName) {
    final left = d.remaining.isNegative ? Duration.zero : d.remaining;
    final countdown =
        '${left.inMinutes}:${(left.inSeconds % 60).toString().padLeft(2, '0')}';
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: IconButton(
              icon: const Icon(Icons.close, color: Colors.white70),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
          const Spacer(),
          const Text('⚔️ DUEL',
              style: TextStyle(
                  fontSize: 44,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                  letterSpacing: 4)),
          const SizedBox(height: 6),
          Text('contre $oppName',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, color: Colors.white)),
          const Spacer(),
          ScaleTransition(
            scale: Tween(begin: 0.93, end: 1.05).animate(
                CurvedAnimation(parent: _pulse, curve: Curves.easeInOut)),
            child: GestureDetector(
              // onTapDown : ça compte dès que le doigt touche l'écran
              onTapDown: (_) => _tap(),
              child: Container(
                width: 230,
                height: 230,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.35),
                      blurRadius: 30,
                      spreadRadius: 4,
                    ),
                  ],
                ),
                child: _tapping
                    ? const CircularProgressIndicator(color: kRed)
                    : const Text('APPUIE !',
                        style: TextStyle(
                            fontSize: 38,
                            fontWeight: FontWeight.w900,
                            color: Colors.black)),
              ),
            ),
          ),
          const Spacer(),
          const Text('Le premier qui appuie gagne',
              style: TextStyle(color: Colors.white, fontSize: 16)),
          const SizedBox(height: 8),
          Text(countdown,
              style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 18,
                  fontFeatures: [FontFeature.tabularFigures()])),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _done(Duel d, String me, String oppName, String outcome) {
    final String emoji;
    final String title;
    String? detail;
    final winTime = d.winnerTime;
    final myTime = d.timeOf(me);
    switch (outcome) {
      case 'won':
        emoji = '🏆';
        title = 'Victoire !';
        if (winTime != null) detail = 'Tu as appuyé en ${formatDuration(winTime)}';
      case 'lost':
        emoji = '💀';
        title = '$oppName a été plus rapide';
        detail = [
          if (winTime != null) '$oppName : ${formatDuration(winTime)}',
          if (myTime != null) 'Toi : ${formatDuration(myTime)}',
        ].join('   ·   ');
      default:
        emoji = '🤝';
        title = 'Match nul';
        detail = 'Personne n\'a appuyé à temps.';
    }
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(emoji, textAlign: TextAlign.center, style: const TextStyle(fontSize: 96)),
          const SizedBox(height: 16),
          Text(title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
          if (detail != null && detail.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(detail,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, color: Colors.white70)),
          ],
          const SizedBox(height: 40),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: kRed,
              minimumSize: const Size.fromHeight(52),
            ),
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Retour'),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// L'onglet Duels : bilan, classement, historique
// =============================================================================

class DuelsTab extends StatelessWidget {
  const DuelsTab({super.key, required this.store, required this.cloud});

  final Store store;
  final Cloud cloud;

  void _open(BuildContext context, Duel d) {
    Navigator.of(context).push(MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => DuelScreen(cloud: cloud, duelId: d.id),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Duels')),
      body: ListenableBuilder(
        listenable: cloud,
        builder: (context, _) {
          if (!Cloud.configured) {
            return const _Info('Les duels ont besoin du serveur (voir le README).');
          }
          if (!cloud.duelsAvailable) {
            return const _Info(
                'Les duels ne sont pas encore activés sur le serveur : lance le '
                'fichier supabase_duels.sql dans Supabase (SQL Editor → Run).');
          }
          final text = Theme.of(context).textTheme;
          final me = cloud.myServerId ?? '';
          final s = cloud.myDuelStats;
          final live = cloud.pendingDuel;
          final history = cloud.duels.where((d) => d.involves(me)).take(20).toList();

          return RefreshIndicator(
            onRefresh: cloud.refreshLeaderboard,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (live != null) ...[
                  Material(
                    color: kRed,
                    borderRadius: BorderRadius.circular(16),
                    child: ListTile(
                      leading: const Text('⚔️', style: TextStyle(fontSize: 28)),
                      title: Text('Duel en cours contre ${cloud.nameOf(live.opponentOf(me))}',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: const Text('Appuie ici, vite !'),
                      onTap: () => _open(context, live),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
                if (s.played + s.draws == 0)
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Text(
                      '⚔️ Comment ça marche : quand tu croises un pote, ça vibre '
                      'et un duel se lance. Le premier qui ouvre Festipote et '
                      'appuie sur le bouton gagne ! Un duel max toutes les 10 '
                      'minutes par pote.',
                    ),
                  ),
                if (s.played + s.draws > 0)
                  Row(
                    children: [
                      Expanded(child: _Mini('${s.wins}', 'victoires')),
                      const SizedBox(width: 8),
                      Expanded(child: _Mini('${s.losses}', 'défaites')),
                      const SizedBox(width: 8),
                      Expanded(child: _Mini('${s.streak}', 'série en cours')),
                    ],
                  ),
                const SizedBox(height: 28),
                Text('🏆 Classement', style: text.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                if (cloud.leaderboard.isEmpty)
                  const Text('Le classement apparaîtra après vos premiers duels.',
                      style: TextStyle(color: Colors.white60)),
                for (final (i, row) in cloud.leaderboard.indexed)
                  _LeaderTile(rank: i + 1, row: row, isMe: row.userId == me),
                const SizedBox(height: 28),
                if (history.isNotEmpty) ...[
                  Text('Derniers duels', style: text.titleMedium),
                  const SizedBox(height: 4),
                  for (final d in history) _HistoryTile(duel: d, me: me, cloud: cloud),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

class _LeaderTile extends StatelessWidget {
  const _LeaderTile({required this.rank, required this.row, required this.isMe});

  final int rank;
  final LeaderRow row;
  final bool isMe;

  @override
  Widget build(BuildContext context) {
    const medals = ['🥇', '🥈', '🥉'];
    final pct = (row.winRate * 100).round();
    final details = [
      '${row.wins} V · ${row.losses} D',
      if (row.played > 0) '$pct %',
      if (row.bestMs != null) 'record ${formatDuration(Duration(milliseconds: row.bestMs!))}',
      '${row.encounters} croisements',
    ].join(' · ');
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 3),
      decoration: BoxDecoration(
        color: isMe ? kRed.withValues(alpha: 0.2) : Colors.white.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(14),
        border: isMe ? Border.all(color: kRed) : null,
      ),
      child: ListTile(
        leading: SizedBox(
          width: 36,
          child: Center(
            child: rank <= 3
                ? Text(medals[rank - 1], style: const TextStyle(fontSize: 26))
                : Text('$rank', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          ),
        ),
        title: Text(isMe ? '${row.name} (toi)' : row.name,
            style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(details, style: const TextStyle(fontSize: 12)),
        trailing: Text('${row.wins}',
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: kRed)),
      ),
    );
  }
}

class _HistoryTile extends StatelessWidget {
  const _HistoryTile({required this.duel, required this.me, required this.cloud});

  final Duel duel;
  final String me;
  final Cloud cloud;

  @override
  Widget build(BuildContext context) {
    final opp = cloud.nameOf(duel.opponentOf(me));
    final (String icon, String label) = switch (duel.outcomeFor(me)) {
      DuelOutcome.won => ('🏆', 'Victoire contre $opp'),
      DuelOutcome.lost => ('💀', 'Défaite contre $opp'),
      DuelOutcome.draw => ('🤝', 'Nul contre $opp'),
      DuelOutcome.pending => ('⏳', 'En cours contre $opp'),
    };
    final t = duel.winnerTime;
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Text(icon, style: const TextStyle(fontSize: 24)),
      title: Text(label),
      subtitle: Text([
        formatSeen(duel.createdAt),
        if (t != null) 'en ${formatDuration(t)}',
      ].join(' · ')),
    );
  }
}

class _Mini extends StatelessWidget {
  const _Mini(this.value, this.label);

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Text(value,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: kRed)),
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70)),
        ],
      ),
    );
  }
}

class _Info extends StatelessWidget {
  const _Info(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Text(text,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70)),
      ),
    );
  }
}
