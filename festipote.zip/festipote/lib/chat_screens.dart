import 'package:flutter/material.dart';

import 'cloud.dart';
import 'main.dart' show kRed;
import 'store.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key, required this.store, required this.cloud});

  final Store store;
  final Cloud cloud;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chat')),
      body: ListenableBuilder(
        listenable: cloud,
        builder: (context, _) {
          if (!Cloud.configured) {
            return const _Info(
              'Le chat a besoin du serveur. Suis la partie « Serveur » du '
              'README pour l\'activer.',
            );
          }
          if (store.friends.isEmpty) {
            return const _Info('Ajoute des potes pour discuter avec eux.');
          }
          final friends = [...store.friends]..sort((a, b) {
              final ta = cloud.lastMessageWith(a)?.id ?? 0;
              final tb = cloud.lastMessageWith(b)?.id ?? 0;
              return tb.compareTo(ta);
            });
          return ListView(
            children: [
              if (!cloud.online)
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: Text(
                    'Pas de réseau pour l\'instant : le chat revient avec la connexion.',
                    style: TextStyle(color: Colors.white60),
                  ),
                ),
              for (final f in friends) _ChatTile(friend: f, cloud: cloud, store: store),
            ],
          );
        },
      ),
    );
  }
}

class _ChatTile extends StatelessWidget {
  const _ChatTile({required this.friend, required this.cloud, required this.store});

  final Friend friend;
  final Cloud cloud;
  final Store store;

  @override
  Widget build(BuildContext context) {
    final last = cloud.lastMessageWith(friend);
    final unread = cloud.unreadWith(friend);
    final String subtitle;
    if (last != null) {
      subtitle = (last.sender == cloud.myServerId ? 'Toi : ' : '') + last.body;
    } else if (friend.serverId == null) {
      subtitle = 'Pas encore relié·e en ligne';
    } else {
      subtitle = 'Pas encore de message';
    }
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: unread > 0 ? kRed : Colors.white12,
        foregroundColor: Colors.white,
        child: Text(friend.name.characters.first.toUpperCase()),
      ),
      title: Text(friend.name,
          style: TextStyle(
              fontWeight: unread > 0 ? FontWeight.w800 : FontWeight.normal)),
      subtitle: Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: unread > 0
          ? Badge(label: Text('$unread'), backgroundColor: kRed)
          : last != null
              ? Text(formatTime(last.createdAt),
                  style: const TextStyle(color: Colors.white54, fontSize: 12))
              : null,
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => ChatScreen(friend: friend, cloud: cloud),
      )),
    );
  }
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.friend, required this.cloud});

  final Friend friend;
  final Cloud cloud;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctrl = TextEditingController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    widget.cloud.openChat = widget.friend.serverId;
  }

  @override
  void dispose() {
    widget.cloud.openChat = null;
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    final ok = await widget.cloud.send(widget.friend, text);
    if (!mounted) return;
    setState(() => _sending = false);
    if (ok) {
      _ctrl.clear();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Message pas envoyé : vérifie ton réseau.'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final cloud = widget.cloud;
    final friend = widget.friend;
    return Scaffold(
      appBar: AppBar(title: Text(friend.name)),
      body: ListenableBuilder(
        listenable: cloud,
        builder: (context, _) {
          final msgs = cloud.conversation(friend);
          if (cloud.unreadWith(friend) > 0) {
            WidgetsBinding.instance
                .addPostFrameCallback((_) => cloud.markRead(friend));
          }
          return Column(
            children: [
              Expanded(
                child: msgs.isEmpty
                    ? const _Info('Dis bonjour 👋')
                    : ListView.builder(
                        reverse: true,
                        padding: const EdgeInsets.all(12),
                        itemCount: msgs.length,
                        itemBuilder: (context, i) {
                          final m = msgs[msgs.length - 1 - i];
                          return _Bubble(
                            message: m,
                            mine: m.sender == cloud.myServerId,
                          );
                        },
                      ),
              ),
              if (friend.serverId == null)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Ton pote n\'est pas encore relié en ligne. Il faut que '
                    'vous ayez tous les deux du réseau et la dernière version '
                    'de l\'appli, puis ça se fait tout seul.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70),
                  ),
                )
              else
                SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 8, 8),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _ctrl,
                            minLines: 1,
                            maxLines: 4,
                            textCapitalization: TextCapitalization.sentences,
                            decoration: InputDecoration(
                              hintText: 'Message',
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 10),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(24),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton.filled(
                          onPressed: _sending ? null : _send,
                          icon: const Icon(Icons.send),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.message, required this.mine});

  final ChatMessage message;
  final bool mine;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        constraints: const BoxConstraints(maxWidth: 290),
        decoration: BoxDecoration(
          color: mine ? kRed : Colors.white12,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment:
              mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(message.body, style: const TextStyle(fontSize: 15)),
            const SizedBox(height: 2),
            Text(
              formatTime(message.createdAt),
              style: const TextStyle(fontSize: 10, color: Colors.white60),
            ),
          ],
        ),
      ),
    );
  }
}

class _Info extends StatelessWidget {
  const _Info(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white70),
        ),
      ),
    );
  }
}
