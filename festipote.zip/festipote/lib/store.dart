import 'dart:convert';
import 'dart:math';

import 'package:shared_preferences/shared_preferences.dart';

class Friend {
  Friend({required this.id, required this.name, this.lastSeen});

  /// Identifiant (UUID) que le téléphone de ce pote diffuse en Bluetooth.
  final String id;
  final String name;
  DateTime? lastSeen;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'lastSeen': lastSeen?.toIso8601String(),
      };

  factory Friend.fromJson(Map<String, dynamic> j) => Friend(
        id: j['id'] as String,
        name: j['name'] as String,
        lastSeen: j['lastSeen'] == null
            ? null
            : DateTime.tryParse(j['lastSeen'] as String),
      );
}

/// Tout est stocké sur le téléphone, rien ne part sur Internet.
class Store {
  static const _kMyId = 'my_id';
  static const _kMyName = 'my_name';
  static const _kFriends = 'friends';
  static const _kRssi = 'rssi_threshold';

  static final _uuidRegex = RegExp(
      r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$');

  late final SharedPreferences _prefs;
  late String myId;
  String? myName;
  List<Friend> friends = [];

  /// Seuil de signal Bluetooth (dBm). Plus il est haut, plus il faut être proche.
  int rssiThreshold = -80;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    myId = _prefs.getString(_kMyId) ?? _newUuid();
    await _prefs.setString(_kMyId, myId);
    myName = _prefs.getString(_kMyName);
    rssiThreshold = _prefs.getInt(_kRssi) ?? -80;
    final raw = _prefs.getString(_kFriends);
    if (raw != null) {
      friends = (jsonDecode(raw) as List)
          .map((e) => Friend.fromJson(e as Map<String, dynamic>))
          .toList();
    }
  }

  Future<void> setMyName(String name) async {
    myName = name;
    await _prefs.setString(_kMyName, name);
  }

  Future<void> setRssiThreshold(int value) async {
    rssiThreshold = value;
    await _prefs.setInt(_kRssi, value);
  }

  Future<void> saveFriends() => _prefs.setString(
      _kFriends, jsonEncode(friends.map((f) => f.toJson()).toList()));

  /// Contenu de mon QR code, à faire scanner à mes potes.
  String get myQrPayload =>
      jsonEncode({'app': 'festipote', 'id': myId, 'name': myName ?? 'Pote'});

  /// Lit le QR code d'un pote. Renvoie null si ce n'est pas un code Festipote.
  static Friend? parseQr(String raw) {
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      if (j['app'] != 'festipote') return null;
      final id = (j['id'] as String).toLowerCase();
      if (!_uuidRegex.hasMatch(id)) return null;
      final name = (j['name'] as String?)?.trim() ?? '';
      return Friend(id: id, name: name.isEmpty ? 'Pote' : name);
    } catch (_) {
      return null;
    }
  }

  static String _newUuid() {
    final rnd = Random.secure();
    final b = List<int>.generate(16, (_) => rnd.nextInt(256));
    b[6] = (b[6] & 0x0f) | 0x40; // UUID version 4
    b[8] = (b[8] & 0x3f) | 0x80;
    final h = b.map((x) => x.toRadixString(16).padLeft(2, '0')).join();
    return '${h.substring(0, 8)}-${h.substring(8, 12)}-'
        '${h.substring(12, 16)}-${h.substring(16, 20)}-${h.substring(20)}';
  }
}
