import 'dart:convert';
import 'dart:math';

import 'package:shared_preferences/shared_preferences.dart';

class Friend {
  Friend({
    required this.id,
    required this.name,
    this.code,
    this.serverId,
    this.linked = false,
    this.lastSeen,
  });

  /// Identifiant que le téléphone de ce pote diffuse en Bluetooth.
  final String id;
  String name;

  /// Code d'invitation du pote (dans son QR code), pour vous relier en ligne.
  String? code;

  /// Identifiant du pote sur le serveur (carte, chat).
  String? serverId;

  /// Vrai quand l'amitié est enregistrée sur le serveur.
  bool linked;
  DateTime? lastSeen;

  // Dernière position partagée (pas enregistrée sur le téléphone).
  double? lat;
  double? lon;
  DateTime? locationAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'code': code,
        'serverId': serverId,
        'linked': linked,
        'lastSeen': lastSeen?.toIso8601String(),
      };

  factory Friend.fromJson(Map<String, dynamic> j) => Friend(
        id: j['id'] as String,
        name: j['name'] as String,
        code: j['code'] as String?,
        serverId: j['serverId'] as String?,
        linked: j['linked'] as bool? ?? false,
        lastSeen: j['lastSeen'] == null
            ? null
            : DateTime.tryParse(j['lastSeen'] as String),
      );
}

/// Un croisement avec un pote (enregistré à chaque alerte).
class Encounter {
  Encounter(this.friendId, this.time);

  final String friendId;
  final DateTime time;

  Map<String, dynamic> toJson() => {'f': friendId, 't': time.toIso8601String()};

  static Encounter? fromJson(Map<String, dynamic> j) {
    final f = j['f'] as String?;
    final t = DateTime.tryParse(j['t'] as String? ?? '');
    return (f == null || t == null) ? null : Encounter(f, t);
  }
}

/// Données enregistrées sur le téléphone.
class Store {
  static const _kMyId = 'my_id';
  static const _kMyCode = 'my_code';
  static const _kMyName = 'my_name';
  static const _kFriends = 'friends';
  static const _kRssi = 'rssi_threshold';
  static const _kEncounters = 'encounters';
  static const _kLastRead = 'last_read';
  static const _kSharing = 'sharing';
  static const _kRemoved = 'removed';
  static const _kEventId = 'event_id';

  static final _uuidRegex = RegExp(
      r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$');
  static final _share3 = RegExp(
      r'festipote:([0-9a-fA-F-]{36}):([0-9a-fA-F-]{36}):([^\r\n]*)');
  static final _share2 = RegExp(r'festipote:([0-9a-fA-F-]{36}):([^\r\n]*)');

  late final SharedPreferences _prefs;
  late String myId;
  late String myCode;
  String? myName;
  List<Friend> friends = [];

  /// Seuil de signal Bluetooth (dBm). Plus il est haut, plus il faut être proche.
  int rssiThreshold = -80;
  List<Encounter> encounters = [];

  /// Dernier message lu, par identifiant serveur de pote.
  Map<String, int> lastRead = {};
  bool sharing = false;

  /// Potes retirés (pour ne pas les rajouter automatiquement).
  Set<String> removed = {};

  /// Soirée rejointe (mode soirée), null sinon.
  String? eventId;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    myId = _prefs.getString(_kMyId) ?? newUuid();
    await _prefs.setString(_kMyId, myId);
    myCode = _prefs.getString(_kMyCode) ?? newUuid();
    await _prefs.setString(_kMyCode, myCode);
    myName = _prefs.getString(_kMyName);
    rssiThreshold = _prefs.getInt(_kRssi) ?? -80;
    sharing = _prefs.getBool(_kSharing) ?? false;
    eventId = _prefs.getString(_kEventId);
    removed = (_prefs.getStringList(_kRemoved) ?? const <String>[]).toSet();
    friends =
        _decodeList(_prefs.getString(_kFriends)).map(Friend.fromJson).toList();
    encounters = _decodeList(_prefs.getString(_kEncounters))
        .map(Encounter.fromJson)
        .whereType<Encounter>()
        .toList();
    final rawRead = _prefs.getString(_kLastRead);
    if (rawRead != null) {
      try {
        lastRead = (jsonDecode(rawRead) as Map<String, dynamic>)
            .map((k, v) => MapEntry(k, (v as num).toInt()));
      } catch (_) {}
    }
  }

  static List<Map<String, dynamic>> _decodeList(String? raw) {
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List).cast<Map<String, dynamic>>().toList();
    } catch (_) {
      return [];
    }
  }

  Friend? friendByBle(String id) {
    for (final f in friends) {
      if (f.id == id) return f;
    }
    return null;
  }

  Future<void> setMyName(String name) async {
    myName = name;
    await _prefs.setString(_kMyName, name);
  }

  Future<void> setRssiThreshold(int value) async {
    rssiThreshold = value;
    await _prefs.setInt(_kRssi, value);
  }

  Future<void> setSharing(bool value) async {
    sharing = value;
    await _prefs.setBool(_kSharing, value);
  }

  Future<void> saveFriends() => _prefs.setString(
      _kFriends, jsonEncode(friends.map((f) => f.toJson()).toList()));

  Future<void> setEventId(String? id) async {
    eventId = id;
    if (id == null) {
      await _prefs.remove(_kEventId);
    } else {
      await _prefs.setString(_kEventId, id);
    }
  }

  Future<void> saveRemoved() =>
      _prefs.setStringList(_kRemoved, removed.toList());

  Future<void> saveLastRead() =>
      _prefs.setString(_kLastRead, jsonEncode(lastRead));

  Future<void> addEncounter(String friendId, DateTime time) async {
    encounters.add(Encounter(friendId, time));
    if (encounters.length > 5000) {
      encounters.removeRange(0, encounters.length - 5000);
    }
    await _prefs.setString(_kEncounters,
        jsonEncode(encounters.map((e) => e.toJson()).toList()));
  }

  Future<void> clearEncounters() async {
    encounters.clear();
    await _prefs.remove(_kEncounters);
  }

  /// Contenu de mon QR code, à faire scanner à mes potes.
  String get myQrPayload => jsonEncode({
        'app': 'festipote',
        'id': myId,
        'k': myCode,
        'name': myName ?? 'Pote',
      });

  /// Texte à envoyer par message quand on ne peut pas scanner.
  String get myShareText =>
      'Ajoute-moi sur Festipote 📡\nfestipote:$myId:$myCode:${myName ?? 'Pote'}';

  /// Lit un code de pote (QR code ou texte collé).
  /// Renvoie null si ce n'est pas un code Festipote.
  static Friend? parseCode(String raw) {
    final text = raw.trim();
    try {
      final j = jsonDecode(text);
      if (j is Map<String, dynamic> && j['app'] == 'festipote') {
        return _makeFriend(
            j['id'] as String?, j['name'] as String?, j['k'] as String?);
      }
    } catch (_) {}
    final m3 = _share3.firstMatch(text);
    if (m3 != null) return _makeFriend(m3.group(1), m3.group(3), m3.group(2));
    final m2 = _share2.firstMatch(text);
    if (m2 != null) return _makeFriend(m2.group(1), m2.group(2), null);
    return null;
  }

  static Friend? _makeFriend(String? id, String? name, String? code) {
    if (id == null) return null;
    final cleanId = id.toLowerCase();
    if (!_uuidRegex.hasMatch(cleanId)) return null;
    final cleanCode = code?.toLowerCase();
    final validCode =
        cleanCode != null && _uuidRegex.hasMatch(cleanCode) ? cleanCode : null;
    final cleanName = (name ?? '').trim();
    return Friend(
      id: cleanId,
      name: cleanName.isEmpty ? 'Pote' : cleanName,
      code: validCode,
    );
  }

  static String newUuid() {
    final rnd = Random.secure();
    final b = List<int>.generate(16, (_) => rnd.nextInt(256));
    b[6] = (b[6] & 0x0f) | 0x40; // UUID version 4
    b[8] = (b[8] & 0x3f) | 0x80;
    final h = b.map((x) => x.toRadixString(16).padLeft(2, '0')).join();
    return '${h.substring(0, 8)}-${h.substring(8, 12)}-'
        '${h.substring(12, 16)}-${h.substring(16, 20)}-${h.substring(20)}';
  }
}

// --- Petits utilitaires de dates -------------------------------------------

String _two(int n) => n.toString().padLeft(2, '0');

String formatTime(DateTime t) => '${_two(t.hour)}h${_two(t.minute)}';

bool sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

/// « à 14h32 » aujourd'hui, sinon « le 03/08 à 14h32 ».
String formatSeen(DateTime t) => sameDay(t, DateTime.now())
    ? 'à ${formatTime(t)}'
    : 'le ${_two(t.day)}/${_two(t.month)} à ${formatTime(t)}';

String timeAgo(DateTime t) {
  final d = DateTime.now().difference(t);
  if (d.inMinutes < 1) return 'à l\'instant';
  if (d.inMinutes < 60) return 'il y a ${d.inMinutes} min';
  return 'il y a ${d.inHours} h';
}
