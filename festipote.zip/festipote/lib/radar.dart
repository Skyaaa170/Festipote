import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/widgets.dart';
import 'package:flutter_ble_peripheral/flutter_ble_peripheral.dart'
    show AdvertiseData, AdvertiseSettings, FlutterBlePeripheral;
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:vibration/vibration.dart';

import 'store.dart';

/// Le radar : diffuse ton identifiant en Bluetooth et écoute ceux de tes potes.
/// Tout se passe en local, pas besoin de réseau.
class Radar extends ChangeNotifier {
  Radar(this.store);

  final Store store;
  final _peripheral = FlutterBlePeripheral();
  final _notifications = FlutterLocalNotificationsPlugin();

  /// Pas plus d'une alerte par pote pendant ce délai.
  static const cooldown = Duration(minutes: 10);

  /// Un pote capté il y a moins que ça est affiché « dans le coin ».
  static const nearbyWindow = Duration(seconds: 60);

  static const _vibrationPattern = [0, 400, 150, 400, 150, 900];

  bool active = false;
  bool starting = false;
  String? error;

  /// Appelé quand un pote est détecté pendant que l'appli est à l'écran.
  void Function(String message)? onForegroundAlert;

  final Map<String, DateTime> _lastAlert = {};
  final Map<String, DateTime> _lastHeard = {};
  StreamSubscription<List<ScanResult>>? _scanSub;
  Timer? _androidRestartTimer;
  Timer? _uiTimer;
  DateTime _lastUiRefresh = DateTime(2000);

  bool isNearby(Friend friend) {
    final t = _lastHeard[friend.id];
    return t != null && DateTime.now().difference(t) < nearbyWindow;
  }

  Future<void> initNotifications() async {
    await _notifications.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(),
    ));
  }

  Future<void> toggle() => active ? stop() : start();

  Future<void> setRange(int rssi) async {
    await store.setRssiThreshold(rssi);
    notifyListeners();
  }

  /// À appeler quand la liste de potes change.
  Future<void> friendsChanged() async {
    notifyListeners();
    if (active) await _startScan();
  }

  Future<void> start() async {
    if (starting) return;
    starting = true;
    error = null;
    notifyListeners();
    try {
      if (!await _requestPermissions()) {
        throw 'Autorise le Bluetooth pour Festipote dans les réglages du téléphone.';
      }
      if (!await FlutterBluePlus.isSupported) {
        throw 'Ce téléphone ne gère pas le Bluetooth Low Energy.';
      }
      await _ensureBluetoothOn();
      await _startAdvertising();
      await _startScan();
      _uiTimer = Timer.periodic(
          const Duration(seconds: 15), (_) => notifyListeners());
      if (Platform.isAndroid) {
        // Android bride les scans qui durent plus de 30 min : on relance.
        _androidRestartTimer = Timer.periodic(
            const Duration(minutes: 10), (_) => _restartAndroid());
      }
      active = true;
    } catch (e) {
      error = e.toString();
      await _stopBle();
    } finally {
      starting = false;
      notifyListeners();
    }
  }

  Future<void> stop() async {
    await _stopBle();
    active = false;
    notifyListeners();
  }

  // ---------------------------------------------------------------------------

  Future<bool> _requestPermissions() async {
    // Sur iPhone, le système demande tout seul au premier usage.
    if (!Platform.isAndroid) return true;
    final result = await [
      Permission.bluetoothScan,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse, // utile seulement sur Android 11 et moins
      Permission.notification,
    ].request();
    return result[Permission.bluetoothScan]!.isGranted &&
        result[Permission.bluetoothAdvertise]!.isGranted;
  }

  Future<void> _ensureBluetoothOn() async {
    var state = await FlutterBluePlus.adapterState
        .where((s) => s != BluetoothAdapterState.unknown)
        .first
        .timeout(const Duration(seconds: 5),
            onTimeout: () => BluetoothAdapterState.unknown);
    if (state == BluetoothAdapterState.on) return;

    if (Platform.isAndroid) {
      try {
        await FlutterBluePlus.turnOn();
      } catch (_) {}
      state = await FlutterBluePlus.adapterState
          .where((s) => s == BluetoothAdapterState.on)
          .first
          .timeout(const Duration(seconds: 10),
              onTimeout: () => BluetoothAdapterState.off);
      if (state == BluetoothAdapterState.on) return;
    }
    throw 'Active le Bluetooth (et autorise Festipote à l\'utiliser), puis réessaie.';
  }

  Future<void> _startAdvertising() async {
    Future<void> advertise() => _peripheral.start(
          advertiseData: AdvertiseData(serviceUuid: store.myId),
          // Android : timeout 0 = diffuser sans limite de durée.
          advertiseSettings: AdvertiseSettings(timeout: 0, connectable: false),
        );
    try {
      await advertise();
    } catch (_) {
      // Sur iPhone, le Bluetooth met parfois une seconde à être prêt.
      await Future.delayed(const Duration(seconds: 1));
      await advertise();
    }
  }

  Future<void> _startScan() async {
    await _scanSub?.cancel();
    _scanSub = null;
    if (FlutterBluePlus.isScanningNow) await FlutterBluePlus.stopScan();

    // Sans potes, on ne scanne pas, mais on continue d'émettre
    // pour que les autres puissent te capter.
    if (store.friends.isEmpty) return;

    _scanSub = FlutterBluePlus.onScanResults.listen(_onScanResults);
    await FlutterBluePlus.startScan(
      // Filtrer sur les identifiants des potes est indispensable sur iPhone
      // pour que le scan continue écran verrouillé.
      withServices: store.friends.map((f) => Guid(f.id)).toList(),
      continuousUpdates: true,
      androidScanMode: AndroidScanMode.balanced,
    );
  }

  void _onScanResults(List<ScanResult> results) {
    final now = DateTime.now();
    for (final r in results) {
      if (now.difference(r.timeStamp) > const Duration(seconds: 10)) continue;
      if (r.rssi < store.rssiThreshold) continue; // signal faible = trop loin

      final uuids = r.advertisementData.serviceUuids
          .map((g) => g.toString().toLowerCase())
          .toSet();
      Friend? friend;
      for (final f in store.friends) {
        if (uuids.contains(f.id)) {
          friend = f;
          break;
        }
      }
      if (friend != null) {
        _lastHeard[friend.id] = now;
        friend.lastSeen = now;
      }
      // friend == null : un iPhone en arrière-plan masque son identifiant.
      // Comme on ne scanne QUE les identifiants de tes potes, c'est forcément
      // l'un d'eux, on prévient quand même sans pouvoir dire lequel.
      _alert(friend, now);
    }
    if (now.difference(_lastUiRefresh) > const Duration(seconds: 2)) {
      _lastUiRefresh = now;
      notifyListeners();
    }
  }

  Future<void> _alert(Friend? friend, DateTime now) async {
    final key = friend?.id ?? 'inconnu';
    final last = _lastAlert[key];
    if (last != null && now.difference(last) < cooldown) return;
    _lastAlert[key] = now;
    if (friend != null) await store.saveFriends();

    final title = '${friend?.name ?? 'Un·e de tes potes'} est dans le coin 👀';
    const body = 'Lève la tête, c\'est à quelques mètres de toi.';

    final inForeground =
        WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed;
    if (inForeground) {
      if (await Vibration.hasVibrator() == true) {
        Vibration.vibrate(pattern: _vibrationPattern);
      }
      onForegroundAlert?.call(title);
      return;
    }

    // En arrière-plan / écran verrouillé : une notification fait vibrer.
    await _notifications.show(
      key.hashCode & 0x7fffffff,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          'potes_proches',
          'Potes à proximité',
          channelDescription: 'Alerte quand un pote passe tout près',
          importance: Importance.high,
          priority: Priority.high,
          enableVibration: true,
          vibrationPattern: Int64List.fromList(_vibrationPattern),
        ),
        iOS: const DarwinNotificationDetails(
          presentAlert: true,
          presentSound: true,
        ),
      ),
    );
  }

  Future<void> _restartAndroid() async {
    try {
      await _startScan();
      await _peripheral.stop();
      await _startAdvertising();
    } catch (_) {}
  }

  Future<void> _stopBle() async {
    _androidRestartTimer?.cancel();
    _uiTimer?.cancel();
    await _scanSub?.cancel();
    _scanSub = null;
    try {
      await FlutterBluePlus.stopScan();
    } catch (_) {}
    try {
      await _peripheral.stop();
    } catch (_) {}
  }
}
