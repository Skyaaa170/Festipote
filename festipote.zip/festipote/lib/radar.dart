import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/widgets.dart';
import 'package:flutter_ble_peripheral/flutter_ble_peripheral.dart'
    show AdvertiseData, AdvertiseSettings, FlutterBlePeripheral;
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:vibration/vibration.dart';

import 'store.dart';

/// Réglages du mode soirée, envoyés par le serveur.
class EventRadarConfig {
  const EventRadarConfig({
    required this.eventId,
    required this.myNum,
    required this.rssi,
    required this.dwellSec,
    required this.pairCooldownMin,
    required this.userCooldownMin,
    required this.paused,
  });

  final String eventId; // diffusé comme identifiant Bluetooth commun
  final int myNum; // mon numéro dans la soirée
  final int rssi;
  final int dwellSec;
  final int pairCooldownMin;
  final int userCooldownMin;
  final bool paused;

  bool sameRadio(EventRadarConfig? o) =>
      o != null && o.eventId == eventId && o.myNum == myNum;
}

class _Nearby {
  _Nearby(this.rssi, this.since);
  double rssi; // signal lissé
  DateTime since; // proche depuis
  DateTime lastStrong = DateTime(2000);
}

/// Le radar : diffuse ton identifiant en Bluetooth et écoute ceux de tes potes.
/// Tout se passe en local, pas besoin de réseau.
class Radar extends ChangeNotifier {
  Radar(this.store);

  final Store store;
  final _peripheral = FlutterBlePeripheral();
  final _notifications = FlutterLocalNotificationsPlugin();

  /// Pas plus d'une alerte par pote pendant ce délai.
  static const cooldown = Duration(minutes: 10);

  /// Un pote capté il y a moins que ça est affiché « dans le coin ».
  static const nearbyWindow = Duration(seconds: 60);

  static const _vibrationPattern = [0, 400, 150, 400, 150, 900];

  bool active = false;
  bool starting = false;
  String? error;

  /// Appelé quand un pote est détecté pendant que l'appli est à l'écran.
  void Function(String message)? onForegroundAlert;

  /// Appelé à chaque croisement d'un pote identifié (duel, stats en ligne).
  void Function(Friend friend)? onEncounter;

  /// Mode soirée : appelé quand on est resté assez longtemps près du numéro [num].
  void Function(int num)? onEventEncounter;

  /// Mode soirée en cours (null = mode potes normal).
  EventRadarConfig? eventConfig;
  static const eventManufacturerId = 0xFFFF;
  final Map<int, _Nearby> _near = {};
  final Map<int, DateTime> _pairTrigger = {};
  DateTime? _lastEventTrigger;

  /// Nombre de participants captés tout près ces 30 dernières secondes.
  int get eventNearbyCount {
    final now = DateTime.now();
    return _near.values
        .where((n) => now.difference(n.lastStrong) < const Duration(seconds: 30))
        .length;
  }

  /// Même identifiant de notification pour un pote : le duel remplace l'alerte.
  static int notificationIdFor(String bleId) => bleId.hashCode & 0x7fffffff;

  final Map<String, DateTime> _lastAlert = {};
  final Map<String, DateTime> _lastHeard = {};
  StreamSubscription<List<ScanResult>>? _scanSub;
  Timer? _androidRestartTimer;
  Timer? _uiTimer;
  DateTime _lastUiRefresh = DateTime(2000);

  bool isNearby(Friend friend) {
    final t = _lastHeard[friend.id];
    return t != null && DateTime.now().difference(t) < nearbyWindow;
  }

  Future<void> initNotifications() async {
    await _notifications.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(),
    ));
  }

  Future<void> toggle() => active ? stop() : start();

  /// Redessine les écrans qui écoutent le radar.
  void refresh() => notifyListeners();

  Future<void> setRange(int rssi) async {
    await store.setRssiThreshold(rssi);
    notifyListeners();
  }

  /// À appeler quand la liste de potes change.
  Future<void> friendsChanged() async {
    notifyListeners();
    if (active && eventConfig == null) await _startScan();
  }

  /// Passe en mode soirée (ou revient au mode potes avec null).
  Future<void> setEvent(EventRadarConfig? cfg) async {
    final before = eventConfig;
    eventConfig = cfg;
    final radioChanged =
        (before == null) != (cfg == null) || (cfg != null && !cfg.sameRadio(before));
    if (radioChanged) {
      _near.clear();
      _pairTrigger.clear();
      _lastEventTrigger = null;
      if (active) {
        try {
          await _peripheral.stop();
          await _startAdvertising();
          await _startScan();
        } catch (e) {
          error = e.toString();
        }
      }
    }
    notifyListeners();
  }

  /// Vibration courte (utilisée quand un duel démarre appli ouverte).
  Future<void> buzz() async {
    if (await Vibration.hasVibrator() == true) {
      Vibration.vibrate(pattern: _vibrationPattern);
    }
  }

  Future<void> start() async {
    if (starting) return;
    starting = true;
    error = null;
    notifyListeners();
    try {
      if (!await _requestPermissions()) {
        throw 'Autorise le Bluetooth pour Festipote dans les réglages du téléphone.';
      }
      if (!await FlutterBluePlus.isSupported) {
        throw 'Ce téléphone ne gère pas le Bluetooth Low Energy.';
      }
      await _ensureBluetoothOn();
      await _startAdvertising();
      await _startScan();
      _uiTimer = Timer.periodic(
          const Duration(seconds: 15), (_) => notifyListeners());
      if (Platform.isAndroid) {
        // Android bride les scans qui durent plus de 30 min : on relance.
        _androidRestartTimer = Timer.periodic(
            const Duration(minutes: 10), (_) => _restartAndroid());
      }
      active = true;
    } catch (e) {
      error = e.toString();
      await _stopBle();
    } finally {
      starting = false;
      notifyListeners();
    }
  }

  Future<void> stop() async {
    await _stopBle();
    active = false;
    notifyListeners();
  }

  // ---------------------------------------------------------------------------

  Future<bool> _requestPermissions() async {
    // Sur iPhone, le système demande tout seul au premier usage.
    if (!Platform.isAndroid) return true;
    final result = await [
      Permission.bluetoothScan,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse, // utile seulement sur Android 11 et moins
      Permission.notification,
    ].request();
    return result[Permission.bluetoothScan]!.isGranted &&
        result[Permission.bluetoothAdvertise]!.isGranted;
  }

  Future<void> _ensureBluetoothOn() async {
    var state = await FlutterBluePlus.adapterState
        .where((s) => s != BluetoothAdapterState.unknown)
        .first
        .timeout(const Duration(seconds: 5),
            onTimeout: () => BluetoothAdapterState.unknown);
    if (state == BluetoothAdapterState.on) return;

    if (Platform.isAndroid) {
      try {
        await FlutterBluePlus.turnOn();
      } catch (_) {}
      state = await FlutterBluePlus.adapterState
          .where((s) => s == BluetoothAdapterState.on)
          .first
          .timeout(const Duration(seconds: 10),
              onTimeout: () => BluetoothAdapterState.off);
      if (state == BluetoothAdapterState.on) return;
    }
    throw 'Active le Bluetooth (et autorise Festipote à l\'utiliser), puis réessaie.';
  }

  Future<void> _startAdvertising() async {
    final cfg = eventConfig;
    final data = cfg == null
        ? AdvertiseData(serviceUuid: store.myId)
        // Mode soirée : identifiant commun de la soirée + mon numéro (4 octets)
        : AdvertiseData(
            serviceUuid: cfg.eventId,
            manufacturerId: eventManufacturerId,
            manufacturerData: Uint8List.fromList([
              (cfg.myNum >> 24) & 0xff,
              (cfg.myNum >> 16) & 0xff,
              (cfg.myNum >> 8) & 0xff,
              cfg.myNum & 0xff,
            ]),
          );
    Future<void> advertise() => _peripheral.start(
          advertiseData: data,
          // Android : timeout 0 = diffuser sans limite de durée.
          advertiseSettings: AdvertiseSettings(timeout: 0, connectable: false),
        );
    try {
      await advertise();
    } catch (_) {
      // Sur iPhone, le Bluetooth met parfois une seconde à être prêt.
      await Future.delayed(const Duration(seconds: 1));
      await advertise();
    }
  }

  Future<void> _startScan() async {
    await _scanSub?.cancel();
    _scanSub = null;
    if (FlutterBluePlus.isScanningNow) await FlutterBluePlus.stopScan();

    final cfg = eventConfig;
    // Sans potes, on ne scanne pas, mais on continue d'émettre
    // pour que les autres puissent te capter.
    if (cfg == null && store.friends.isEmpty) return;

    _scanSub = FlutterBluePlus.onScanResults
        .listen(cfg == null ? _onScanResults : _onEventResults);
    await FlutterBluePlus.startScan(
      // Filtrer sur des identifiants précis est indispensable sur iPhone
      // pour que le scan continue écran verrouillé.
      withServices: cfg == null
          ? store.friends.map((f) => Guid(f.id)).toList()
          : [Guid(cfg.eventId)],
      continuousUpdates: true,
      androidScanMode: AndroidScanMode.balanced,
    );
  }

  /// Mode soirée : on déclenche un duel seulement si on reste près de
  /// quelqu'un pendant [EventRadarConfig.dwellSec] secondes (salle bondée).
  void _onEventResults(List<ScanResult> results) {
    final cfg = eventConfig;
    if (cfg == null) return;
    final now = DateTime.now();
    for (final r in results) {
      if (now.difference(r.timeStamp) > const Duration(seconds: 10)) continue;
      final data = r.advertisementData.manufacturerData[eventManufacturerId];
      if (data == null || data.length < 4) continue;
      final num = (data[0] << 24) | (data[1] << 16) | (data[2] << 8) | data[3];
      if (num == cfg.myNum) continue;

      final n = _near.putIfAbsent(num, () => _Nearby(r.rssi.toDouble(), now));
      n.rssi = n.rssi * 0.7 + r.rssi * 0.3; // lissage : le signal saute beaucoup
      if (n.rssi < cfg.rssi) continue; // pas assez près
      // Perdu de vue plus de 12 s : le compteur repart de zéro
      if (now.difference(n.lastStrong) > const Duration(seconds: 12)) n.since = now;
      n.lastStrong = now;

      if (cfg.paused) continue;
      if (now.difference(n.since) < Duration(seconds: cfg.dwellSec)) continue;
      final lastPair = _pairTrigger[num];
      if (lastPair != null &&
          now.difference(lastPair) < Duration(minutes: cfg.pairCooldownMin)) {
        continue;
      }
      final lastAny = _lastEventTrigger;
      if (lastAny != null &&
          now.difference(lastAny) < Duration(minutes: cfg.userCooldownMin)) {
        continue;
      }
      _pairTrigger[num] = now;
      _lastEventTrigger = now;
      n.since = now;
      onEventEncounter?.call(num); // le serveur vérifie aussi toutes les règles
    }
    if (now.difference(_lastUiRefresh) > const Duration(seconds: 2)) {
      _lastUiRefresh = now;
      notifyListeners();
    }
  }

  void _onScanResults(List<ScanResult> results) {
    final now = DateTime.now();
    for (final r in results) {
      if (now.difference(r.timeStamp) > const Duration(seconds: 10)) continue;
      if (r.rssi < store.rssiThreshold) continue; // signal faible = trop loin

      final uuids = r.advertisementData.serviceUuids
          .map((g) => g.toString().toLowerCase())
          .toSet();
      Friend? friend;
      for (final f in store.friends) {
        if (uuids.contains(f.id)) {
          friend = f;
          break;
        }
      }
      if (friend != null) {
        _lastHeard[friend.id] = now;
        friend.lastSeen = now;
      }
      // friend == null : un iPhone en arrière-plan masque son identifiant.
      // Comme on ne scanne QUE les identifiants de tes potes, c'est forcément
      // l'un d'eux, on prévient quand même sans pouvoir dire lequel.
      _alert(friend, now);
    }
    if (now.difference(_lastUiRefresh) > const Duration(seconds: 2)) {
      _lastUiRefresh = now;
      notifyListeners();
    }
  }

  Future<void> _alert(Friend? friend, DateTime now) async {
    final key = friend?.id ?? 'inconnu';
    final last = _lastAlert[key];
    if (last != null && now.difference(last) < cooldown) return;
    _lastAlert[key] = now;
    if (friend != null) {
      await store.saveFriends();
      await store.addEncounter(friend.id, now); // pour les stats
      notifyListeners();
    }

    final title = '${friend?.name ?? 'Un·e de tes potes'} est dans le coin 👀';
    const body = 'Lève la tête, c\'est à quelques mètres de toi.';

    final inForeground =
        WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed;
    if (inForeground) {
      if (await Vibration.hasVibrator() == true) {
        Vibration.vibrate(pattern: _vibrationPattern);
      }
      onForegroundAlert?.call(title);
    } else {
      // En arrière-plan / écran verrouillé : une notification fait vibrer.
      await _notifications.show(
        notificationIdFor(key),
        title,
        body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            'potes_proches',
            'Potes à proximité',
            channelDescription: 'Alerte quand un pote passe tout près',
            importance: Importance.high,
            priority: Priority.high,
            enableVibration: true,
            vibrationPattern: Int64List.fromList(_vibrationPattern),
          ),
          iOS: const DarwinNotificationDetails(
            presentAlert: true,
            presentSound: true,
          ),
        ),
      );
    }
    // Après la notification : le duel (s'il y en a un) la remplacera.
    if (friend != null) onEncounter?.call(friend);
  }


  /// Notification simple (utilisée aussi pour les messages du chat).
  Future<void> notify(int id, String title, String body, {bool duel = false}) =>
      _notifications.show(
        id,
        title,
        body,
        NotificationDetails(
          android: duel
              ? AndroidNotificationDetails(
                  'duels',
                  'Duels',
                  channelDescription: 'Défis quand tu croises un pote',
                  importance: Importance.max,
                  priority: Priority.max,
                  enableVibration: true,
                  vibrationPattern: Int64List.fromList(
                      const [0, 150, 80, 150, 80, 150, 80, 700]),
                )
              : const AndroidNotificationDetails(
                  'messages',
                  'Messages',
                  channelDescription: 'Messages de tes potes',
                  importance: Importance.high,
                  priority: Priority.high,
                ),
          iOS: const DarwinNotificationDetails(
              presentAlert: true, presentSound: true),
        ),
      );

  Future<void> _restartAndroid() async {
    try {
      await _startScan();
      await _peripheral.stop();
      await _startAdvertising();
    } catch (_) {}
  }

  Future<void> _stopBle() async {
    _androidRestartTimer?.cancel();
    _uiTimer?.cancel();
    await _scanSub?.cancel();
    _scanSub = null;
    try {
      await FlutterBluePlus.stopScan();
    } catch (_) {}
    try {
      await _peripheral.stop();
    } catch (_) {}
  }
}
