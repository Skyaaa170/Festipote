import 'package:flutter/material.dart';

import 'radar.dart';
import 'screens.dart';
import 'store.dart';

final messengerKey = GlobalKey<ScaffoldMessengerState>();

const kRed = Color(0xFFB3121B);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = Store();
  await store.init();

  final radar = Radar(store);
  await radar.initNotifications();
  radar.onForegroundAlert = (message) =>
      messengerKey.currentState?.showSnackBar(SnackBar(
        content: Text(message, style: const TextStyle(fontSize: 16)),
        backgroundColor: kRed,
        duration: const Duration(seconds: 6),
      ));

  runApp(FestipoteApp(store: store, radar: radar));
}

class FestipoteApp extends StatelessWidget {
  const FestipoteApp({super.key, required this.store, required this.radar});

  final Store store;
  final Radar radar;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Festipote',
      debugShowCheckedModeBanner: false,
      scaffoldMessengerKey: messengerKey,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: kRed,
        scaffoldBackgroundColor: Colors.black,
        appBarTheme: const AppBarTheme(backgroundColor: Colors.black),
      ),
      home: store.myName == null
          ? NameScreen(store: store, radar: radar)
          : HomeScreen(store: store, radar: radar),
    );
  }
}
