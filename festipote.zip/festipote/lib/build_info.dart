// Remplacé à la compilation par le numéro de build GitHub.
const appBuild = 'dev';
