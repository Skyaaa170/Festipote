// Rempli automatiquement à la compilation à partir du fichier supabase.txt
// placé à la racine du dépôt GitHub (voir README). Vide = carte et chat désactivés.
const supabaseUrl = '';
const supabaseKey = '';
