import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'duel_models.dart';
import 'radar.dart';
import 'store.dart';

class ChatMessage {
  ChatMessage({
    required this.id,
    required this.sender,
    required this.recipient,
    required this.body,
    required this.createdAt,
  });

  final int id;
  final String sender;
  final String recipient;
  final String body;
  final DateTime createdAt;

  factory ChatMessage.fromRow(Map<String, dynamic> r) => ChatMessage(
        id: (r['id'] as num).toInt(),
        sender: r['sender'] as String,
        recipient: r['recipient'] as String,
        body: r['body'] as String,
        createdAt: DateTime.parse(r['created_at'] as String).toLocal(),
      );
}

/// Partie en ligne (carte + chat), hébergée sur Supabase.
/// Le radar Bluetooth et les stats marchent sans elle.
class Cloud extends ChangeNotifier {
  Cloud(this.store, this.radar);

  final Store store;
  final Radar radar;

  static bool get configured =>
      supabaseUrl.isNotEmpty && supabaseKey.isNotEmpty;

  bool online = false;
  String? myServerId;
  List<ChatMessage> messages = [];
  Position? myPosition;
  bool get sharing => _posSub != null;

  /// Conversation ouverte à l'écran (pas de notification pour elle).
  String? openChat;

  // Duels
  List<Duel> duels = [];
  List<LeaderRow> leaderboard = [];

  /// Faux si le fichier supabase_duels.sql n'a pas encore été lancé.
  bool duelsAvailable = true;

  // Mode soirée
  EventInfo? event;
  List<LeaderRow> eventBoard = [];

  bool _initialized = false;
  bool _profilePushed = false;
  bool _syncing = false;
  bool _msgAlive = false;
  int? _maxSeenId;
  StreamSubscription<List<Map<String, dynamic>>>? _msgSub;
  StreamSubscription<Position>? _posSub;
  StreamSubscription<List<Map<String, dynamic>>>? _duelSub;
  bool _duelAlive = false;
  int? _maxSeenDuelId;
  final Map<int, String?> _knownWinner = {};
  Timer? _timer;
  DateTime _lastUpload = DateTime(2000);

  SupabaseClient get _db => Supabase.instance.client;

  Future<void> init() async {
    if (!configured) return;
    try {
      await Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);
      _initialized = true;
    } catch (e) {
      debugPrint('Supabase : $e');
      return;
    }
    radar.onEncounter = (f) => unawaited(_onEncounter(f));
    radar.onEventEncounter = (num) => unawaited(_onEventEncounter(num));
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => sync());
    unawaited(sync());
    if (store.sharing) unawaited(startSharing());
  }

  // ---------------------------------------------------------------------------
  // Synchronisation
  // ---------------------------------------------------------------------------

  Future<void> sync() async {
    if (!_initialized || _syncing) return;
    _syncing = true;
    try {
      if (_db.auth.currentUser == null) {
        await _db.auth.signInAnonymously();
      }
      myServerId = _db.auth.currentUser!.id;
      if (!_profilePushed) await _pushProfile();
      if (!_msgAlive) _listenMessages();
      if (!_duelAlive) _listenDuels();
      await _linkPendingFriends();
      await _pullFriends();
      await _heartbeat();
      online = true;
    } catch (e) {
      debugPrint('Sync : $e');
      online = false;
    } finally {
      _syncing = false;
      notifyListeners();
    }
    if (online) {
      await _syncEvent();
      await refreshLeaderboard();
    }
  }

  /// À appeler quand le prénom change.
  Future<void> refreshProfile() async {
    _profilePushed = false;
    await sync();
  }

  Future<void> _pushProfile() async {
    await _db.from('profiles').upsert({
      'id': myServerId,
      'ble_id': store.myId,
      'name': store.myName ?? 'Pote',
    });
    await _db
        .from('invites')
        .upsert({'user_id': myServerId, 'code': store.myCode});
    _profilePushed = true;
  }

  /// Relie sur le serveur les potes ajoutés (même hors ligne).
  Future<void> _linkPendingFriends() async {
    var changed = false;
    for (final f in store.friends) {
      if (f.linked || f.code == null) continue;
      try {
        await _db.rpc('add_friend', params: {'p_ble_id': f.id, 'p_code': f.code});
        f.linked = true;
        changed = true;
      } on PostgrestException catch (e) {
        // « code invalide » : ce pote ne s'est pas encore connecté, on réessaiera.
        if (!e.message.contains('code invalide')) rethrow;
      }
    }
    if (changed) await store.saveFriends();
  }

  /// Récupère les potes (et leur position) depuis le serveur.
  Future<void> _pullFriends() async {
    final rows = await _db
        .from('profiles')
        .select('id, ble_id, name, lat, lon, location_at');
    final seen = <String>{};
    var added = false;
    for (final r in rows) {
      final serverId = r['id'] as String;
      if (serverId == myServerId) continue;
      final ble = (r['ble_id'] as String).toLowerCase();
      if (store.removed.contains(ble)) continue;
      seen.add(ble);
      var f = store.friendByBle(ble);
      if (f == null) {
        // Quelqu'un t'a ajouté : on l'ajoute aussi pour le radar Bluetooth.
        f = Friend(id: ble, name: r['name'] as String? ?? 'Pote', linked: true);
        store.friends.add(f);
        added = true;
      }
      f.serverId = serverId;
      f.linked = true;
      f.name = r['name'] as String? ?? f.name;
      f.lat = (r['lat'] as num?)?.toDouble();
      f.lon = (r['lon'] as num?)?.toDouble();
      f.locationAt =
          DateTime.tryParse(r['location_at'] as String? ?? '')?.toLocal();
    }
    for (final f in store.friends) {
      if (!seen.contains(f.id)) {
        f.lat = null;
        f.lon = null;
        f.locationAt = null;
      }
    }
    await store.saveFriends();
    if (added) await radar.friendsChanged();
  }

  Future<void> friendAdded(Friend f) async {
    store.removed.remove(f.id);
    await store.saveRemoved();
    unawaited(sync());
  }

  Future<void> unlink(Friend f) async {
    store.removed.add(f.id);
    await store.saveRemoved();
    final me = myServerId;
    final them = f.serverId;
    if (!_initialized || me == null || them == null) return;
    try {
      await _db.from('friendships').delete().eq('user_id', me).eq('friend_id', them);
      await _db.from('friendships').delete().eq('user_id', them).eq('friend_id', me);
    } catch (e) {
      debugPrint('Retrait : $e');
    }
  }

  Friend? friendByServerId(String id) {
    for (final f in store.friends) {
      if (f.serverId == id) return f;
    }
    return null;
  }

  // ---------------------------------------------------------------------------
  // Chat
  // ---------------------------------------------------------------------------

  void _listenMessages() {
    _msgSub?.cancel();
    _msgAlive = true;
    _msgSub = _db
        .from('messages')
        .stream(primaryKey: ['id'])
        .order('created_at', ascending: true)
        .listen(
          _onMessages,
          onError: (Object e) {
            debugPrint('Messages : $e');
            _msgAlive = false;
          },
          onDone: () => _msgAlive = false,
        );
  }

  void _onMessages(List<Map<String, dynamic>> rows) {
    final list = rows.map(ChatMessage.fromRow).toList()
      ..sort((a, b) => a.id.compareTo(b.id));
    final previousMax = _maxSeenId;
    _maxSeenId = max(previousMax ?? 0, list.isEmpty ? 0 : list.last.id);
    if (previousMax != null) {
      for (final m in list) {
        if (m.id > previousMax && m.sender != myServerId && m.sender != openChat) {
          final f = friendByServerId(m.sender);
          unawaited(radar.notify(m.id, f?.name ?? 'Nouveau message', m.body));
        }
      }
    }
    messages = list;
    notifyListeners();
  }

  List<ChatMessage> conversation(Friend f) {
    final id = f.serverId;
    if (id == null) return const [];
    return messages.where((m) => m.sender == id || m.recipient == id).toList();
  }

  ChatMessage? lastMessageWith(Friend f) {
    final c = conversation(f);
    return c.isEmpty ? null : c.last;
  }

  int unreadWith(Friend f) {
    final id = f.serverId;
    if (id == null) return 0;
    final read = store.lastRead[id] ?? 0;
    return messages.where((m) => m.sender == id && m.id > read).length;
  }

  int get totalUnread =>
      store.friends.fold(0, (sum, f) => sum + unreadWith(f));

  void markRead(Friend f) {
    final id = f.serverId;
    final c = conversation(f);
    if (id == null || c.isEmpty) return;
    if ((store.lastRead[id] ?? 0) >= c.last.id) return;
    store.lastRead[id] = c.last.id;
    unawaited(store.saveLastRead());
    notifyListeners();
  }

  Future<bool> send(Friend f, String body) async {
    final to = f.serverId;
    if (!_initialized || to == null) return false;
    try {
      final row = await _db
          .from('messages')
          .insert({'recipient': to, 'body': body})
          .select()
          .single();
      final m = ChatMessage.fromRow(row);
      if (!messages.any((x) => x.id == m.id)) messages = [...messages, m];
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Envoi : $e');
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Duels
  // ---------------------------------------------------------------------------

  bool get _inForeground =>
      WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed;

  String nameOf(String serverId) => serverId == myServerId
      ? (store.myName ?? 'Moi')
      : friendByServerId(serverId)?.name ??
          event?.nameByUser[serverId] ??
          'Participant';

  Duel? duelById(int id) {
    for (final d in duels) {
      if (d.id == id) return d;
    }
    return null;
  }

  /// Duel en cours où je n'ai pas encore appuyé.
  Duel? get pendingDuel {
    final me = myServerId;
    if (me == null) return null;
    for (final d in duels) {
      if (d.isLive && d.tapOf(me) == null) return d;
    }
    return null;
  }

  DuelStats get myDuelStats => DuelStats.compute(duels, myServerId ?? '');

  int _notifIdFor(String opponentServerId) {
    final f = friendByServerId(opponentServerId);
    return Radar.notificationIdFor(f?.id ?? opponentServerId);
  }

  void _duelAlert(String opponent, String title, String body,
      {bool snackbarInApp = false}) {
    if (_inForeground) {
      if (snackbarInApp) {
        radar.onForegroundAlert?.call(title);
      } else {
        unawaited(radar.buzz()); // à l'écran, le duel s'ouvre tout seul
      }
      return;
    }
    unawaited(radar.notify(_notifIdFor(opponent), title, body, duel: true));
  }

  /// Appelé par le radar à chaque croisement : stats en ligne + duel.
  Future<void> _onEncounter(Friend f) async {
    final to = f.serverId;
    final me = myServerId;
    if (!_initialized || !_profilePushed || to == null || me == null) return;
    try {
      await _db.rpc('log_encounter', params: {'p_friend': to});
    } catch (e) {
      debugPrint('Croisement : $e');
    }
    try {
      final rows = await _db.rpc('duel_open', params: {'p_friend': to});
      if (rows is List && rows.isNotEmpty) {
        final d = Duel.fromRow(Map<String, dynamic>.from(rows.first as Map));
        _mergeDuel(d);
        if (d.isLive && d.tapOf(me) == null) {
          _duelAlert(to, '⚔️ Duel contre ${f.name} !',
              'Le premier qui ouvre Festipote et appuie gagne. Vite !');
        }
      }
    } catch (e) {
      debugPrint('Duel : $e');
    }
  }

  void _listenDuels() {
    _duelSub?.cancel();
    _duelAlive = true;
    _duelSub = _db
        .from('duels')
        .stream(primaryKey: ['id'])
        .order('id', ascending: false)
        .limit(500)
        .listen(
          _onDuels,
          onError: (Object e) {
            debugPrint('Duels : $e');
            _duelAlive = false;
          },
          onDone: () => _duelAlive = false,
        );
  }

  void _onDuels(List<Map<String, dynamic>> rows) {
    final me = myServerId;
    final list = rows.map(Duel.fromRow).toList()
      ..sort((a, b) => b.id.compareTo(a.id));
    final firstLoad = _maxSeenDuelId == null;
    final previousMax = _maxSeenDuelId ?? 0;
    _maxSeenDuelId = max(previousMax, list.isEmpty ? 0 : list.first.id);

    if (!firstLoad && me != null) {
      for (final d in list) {
        final opp = d.opponentOf(me);
        final name = nameOf(opp);
        // Un pote vient de me défier
        if (d.id > previousMax && d.playerA != me && d.isLive) {
          _duelAlert(opp, '⚔️ $name te défie !',
              'Le premier qui ouvre Festipote et appuie gagne. Vite !');
        }
        // Un duel vient d'être gagné par mon pote
        if (_knownWinner.containsKey(d.id) &&
            _knownWinner[d.id] == null &&
            d.winner != null &&
            d.winner != me) {
          _duelAlert(opp, '💀 $name a gagné le duel',
              'Plus rapide que toi cette fois… Revanche au prochain croisement !',
              snackbarInApp: true);
        }
      }
    }
    for (final d in list) {
      _knownWinner[d.id] = d.winner;
    }
    duels = list;
    duelsAvailable = true;
    notifyListeners();
  }

  void _mergeDuel(Duel d) {
    final list = [...duels];
    final i = list.indexWhere((x) => x.id == d.id);
    if (i >= 0) {
      list[i] = d;
    } else {
      list.add(d);
    }
    list.sort((a, b) => b.id.compareTo(a.id));
    _knownWinner.putIfAbsent(d.id, () => d.winner);
    _maxSeenDuelId = max(_maxSeenDuelId ?? 0, d.id);
    duels = list;
    notifyListeners();
  }

  /// Appuyer sur le bouton du duel : 'won', 'lost', 'expired' ou 'error'.
  Future<String> tapDuel(int duelId) async {
    if (!_initialized) return 'error';
    try {
      final r = await _db.rpc('duel_tap', params: {'p_duel': duelId});
      unawaited(_refreshDuel(duelId));
      return r is String ? r : 'error';
    } catch (e) {
      debugPrint('Appui : $e');
      return 'error';
    }
  }

  Future<void> _refreshDuel(int id) async {
    try {
      final row = await _db.from('duels').select().eq('id', id).single();
      _mergeDuel(Duel.fromRow(row));
    } catch (_) {}
  }

  Future<void> refreshLeaderboard() async {
    if (!_initialized || myServerId == null) return;
    try {
      final rows = await _db.rpc('leaderboard');
      leaderboard = (rows as List)
          .map((r) => LeaderRow.fromRow(Map<String, dynamic>.from(r as Map)))
          .toList();
      duelsAvailable = true;
    } on PostgrestException catch (e) {
      debugPrint('Classement : ${e.message}');
      // Fonction absente = le SQL des duels n'est pas installé
      if (e.code == 'PGRST202' || e.code == '42883') duelsAvailable = false;
    } catch (e) {
      debugPrint('Classement : $e');
    }
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Mode soirée
  // ---------------------------------------------------------------------------

  /// Rejoint une soirée avec son code. Renvoie un message d'erreur, ou null.
  Future<String?> joinEvent(String code) async {
    if (!_initialized) return 'Le serveur n\'est pas configuré.';
    if (!_profilePushed) await sync();
    if (!_profilePushed) return 'Pas de connexion au serveur, réessaie.';
    try {
      final r = await _db.rpc('event_join', params: {'p_code': code});
      await _applyEvent(r);
      if (event == null) return 'Soirée introuvable ou terminée.';
      await store.setEventId(event!.id);
      if (!radar.active) await radar.start();
      unawaited(refreshEventBoard());
      return null;
    } on PostgrestException catch (e) {
      if (e.message.contains('introuvable')) return 'Soirée introuvable ou terminée.';
      if (e.code == 'PGRST202') {
        return 'Le mode soirée n\'est pas installé sur le serveur (supabase_events.sql).';
      }
      return 'Erreur : ${e.message}';
    } catch (_) {
      return 'Pas de réseau, réessaie.';
    }
  }

  Future<void> leaveEvent() async {
    final id = event?.id ?? store.eventId;
    event = null;
    eventBoard = [];
    await store.setEventId(null);
    await radar.setEvent(null);
    notifyListeners();
    if (id == null || !_initialized) return;
    try {
      await _db.rpc('event_leave', params: {'p_event': id});
    } catch (_) {}
  }

  Future<void> _applyEvent(dynamic json) async {
    if (json is! Map) {
      event = null;
      return;
    }
    final e = EventInfo.fromJson(Map<String, dynamic>.from(json));
    if (!e.active || e.myNum == null) {
      // Soirée terminée par l'orga
      event = null;
      await store.setEventId(null);
      await radar.setEvent(null);
      notifyListeners();
      return;
    }
    event = e;
    await radar.setEvent(EventRadarConfig(
      eventId: e.id,
      myNum: e.myNum!,
      rssi: e.rssi,
      dwellSec: e.dwellSec,
      pairCooldownMin: e.pairCooldownMin,
      userCooldownMin: e.userCooldownMin,
      paused: e.paused,
    ));
    notifyListeners();
  }

  /// Récupère les réglages de la soirée (l'orga peut les changer en direct).
  Future<void> _syncEvent() async {
    final id = store.eventId;
    if (id == null) return;
    try {
      final r = await _db.rpc('event_sync', params: {'p_event': id});
      if (r == null) {
        await leaveEvent(); // on n'est plus inscrit
        return;
      }
      await _applyEvent(r);
      await refreshEventBoard();
    } catch (e) {
      debugPrint('Soirée : $e');
    }
  }

  Future<void> refreshEventBoard() async {
    final id = event?.id;
    if (id == null) return;
    try {
      final rows = await _db.rpc('event_leaderboard', params: {'p_event': id});
      eventBoard = (rows as List)
          .map((r) => LeaderRow.fromRow(Map<String, dynamic>.from(r as Map)))
          .toList();
      notifyListeners();
    } catch (e) {
      debugPrint('Classement soirée : $e');
    }
  }

  /// Le radar a détecté quelqu'un tout près assez longtemps : duel !
  Future<void> _onEventEncounter(int num) async {
    final e = event;
    final me = myServerId;
    if (!_initialized || e == null || me == null) return;
    try {
      final rows = await _db.rpc('event_duel_open', params: {'p_event': e.id, 'p_num': num});
      if (rows is List && rows.isNotEmpty) {
        final d = Duel.fromRow(Map<String, dynamic>.from(rows.first as Map));
        _mergeDuel(d);
        if (d.isLive && d.tapOf(me) == null) {
          final opp = d.opponentOf(me);
          _duelAlert(opp, '⚔️ Duel contre ${nameOf(opp)} !',
              'Le premier qui ouvre Festipote et appuie gagne. Vite !');
        }
      }
    } catch (err) {
      debugPrint('Duel soirée : $err');
    }
  }

  // ---------------------------------------------------------------------------
  // Position
  // ---------------------------------------------------------------------------

  Future<String?> _checkLocation() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      return 'Active la localisation (GPS) du téléphone.';
    }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      return 'Autorise Festipote à accéder à ta position.';
    }
    return null;
  }

  /// Trouve ma position (sans la partager).
  Future<String?> locateMe() async {
    final err = await _checkLocation();
    if (err != null) return err;
    try {
      myPosition ??= await Geolocator.getLastKnownPosition();
      notifyListeners();
      myPosition = await Geolocator.getCurrentPosition(
        locationSettings: LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 20),
        ),
      );
      notifyListeners();
      return null;
    } catch (_) {
      return myPosition == null ? 'Position introuvable pour l\'instant.' : null;
    }
  }

  Future<String?> startSharing() async {
    final err = await _checkLocation();
    if (err != null) return err;
    await _posSub?.cancel();
    final LocationSettings settings = defaultTargetPlatform == TargetPlatform.android
        ? AndroidSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 15,
            intervalDuration: const Duration(seconds: 20),
            // Notification permanente : garde l'appli active écran éteint.
            foregroundNotificationConfig: ForegroundNotificationConfig(
              notificationTitle: 'Festipote partage ta position',
              notificationText: 'Tes potes te voient sur la carte.',
              enableWakeLock: true,
            ),
          )
        : LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 15);
    _posSub = Geolocator.getPositionStream(locationSettings: settings)
        .listen(_onPosition, onError: (Object e) => debugPrint('GPS : $e'));
    await store.setSharing(true);
    notifyListeners();
    return null;
  }

  Future<void> stopSharing() async {
    await _posSub?.cancel();
    _posSub = null;
    await store.setSharing(false);
    notifyListeners();
    final me = myServerId;
    if (!_initialized || me == null) return;
    try {
      await _db
          .from('profiles')
          .update({'lat': null, 'lon': null, 'location_at': null}).eq('id', me);
    } catch (_) {}
  }

  void _onPosition(Position p) {
    myPosition = p;
    notifyListeners();
    if (DateTime.now().difference(_lastUpload) > const Duration(seconds: 20)) {
      unawaited(_upload());
    }
  }

  /// Renvoie la position de temps en temps même sans bouger,
  /// pour ne pas disparaître de la carte de tes potes.
  Future<void> _heartbeat() async {
    if (sharing &&
        DateTime.now().difference(_lastUpload) > const Duration(minutes: 5)) {
      await _upload();
    }
  }

  Future<void> _upload() async {
    final p = myPosition;
    final me = myServerId;
    if (!_initialized || !_profilePushed || p == null || me == null) return;
    _lastUpload = DateTime.now();
    try {
      await _db.from('profiles').update({
        'lat': p.latitude,
        'lon': p.longitude,
        'location_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', me);
    } catch (e) {
      debugPrint('Envoi position : $e');
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _msgSub?.cancel();
    _posSub?.cancel();
    _duelSub?.cancel();
    super.dispose();
  }
}
