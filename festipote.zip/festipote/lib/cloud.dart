import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'radar.dart';
import 'store.dart';

class ChatMessage {
  ChatMessage({
    required this.id,
    required this.sender,
    required this.recipient,
    required this.body,
    required this.createdAt,
  });

  final int id;
  final String sender;
  final String recipient;
  final String body;
  final DateTime createdAt;

  factory ChatMessage.fromRow(Map<String, dynamic> r) => ChatMessage(
        id: (r['id'] as num).toInt(),
        sender: r['sender'] as String,
        recipient: r['recipient'] as String,
        body: r['body'] as String,
        createdAt: DateTime.parse(r['created_at'] as String).toLocal(),
      );
}

/// Partie en ligne (carte + chat), hébergée sur Supabase.
/// Le radar Bluetooth et les stats marchent sans elle.
class Cloud extends ChangeNotifier {
  Cloud(this.store, this.radar);

  final Store store;
  final Radar radar;

  static bool get configured =>
      supabaseUrl.isNotEmpty && supabaseKey.isNotEmpty;

  bool online = false;
  String? myServerId;
  List<ChatMessage> messages = [];
  Position? myPosition;
  bool get sharing => _posSub != null;

  /// Conversation ouverte à l'écran (pas de notification pour elle).
  String? openChat;

  bool _initialized = false;
  bool _profilePushed = false;
  bool _syncing = false;
  bool _msgAlive = false;
  int? _maxSeenId;
  StreamSubscription<List<Map<String, dynamic>>>? _msgSub;
  StreamSubscription<Position>? _posSub;
  Timer? _timer;
  DateTime _lastUpload = DateTime(2000);

  SupabaseClient get _db => Supabase.instance.client;

  Future<void> init() async {
    if (!configured) return;
    try {
      await Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);
      _initialized = true;
    } catch (e) {
      debugPrint('Supabase : $e');
      return;
    }
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => sync());
    unawaited(sync());
    if (store.sharing) unawaited(startSharing());
  }

  // ---------------------------------------------------------------------------
  // Synchronisation
  // ---------------------------------------------------------------------------

  Future<void> sync() async {
    if (!_initialized || _syncing) return;
    _syncing = true;
    try {
      if (_db.auth.currentUser == null) {
        await _db.auth.signInAnonymously();
      }
      myServerId = _db.auth.currentUser!.id;
      if (!_profilePushed) await _pushProfile();
      if (!_msgAlive) _listenMessages();
      await _linkPendingFriends();
      await _pullFriends();
      await _heartbeat();
      online = true;
    } catch (e) {
      debugPrint('Sync : $e');
      online = false;
    } finally {
      _syncing = false;
      notifyListeners();
    }
  }

  /// À appeler quand le prénom change.
  Future<void> refreshProfile() async {
    _profilePushed = false;
    await sync();
  }

  Future<void> _pushProfile() async {
    await _db.from('profiles').upsert({
      'id': myServerId,
      'ble_id': store.myId,
      'name': store.myName ?? 'Pote',
    });
    await _db
        .from('invites')
        .upsert({'user_id': myServerId, 'code': store.myCode});
    _profilePushed = true;
  }

  /// Relie sur le serveur les potes ajoutés (même hors ligne).
  Future<void> _linkPendingFriends() async {
    var changed = false;
    for (final f in store.friends) {
      if (f.linked || f.code == null) continue;
      try {
        await _db.rpc('add_friend', params: {'p_ble_id': f.id, 'p_code': f.code});
        f.linked = true;
        changed = true;
      } on PostgrestException catch (e) {
        // « code invalide » : ce pote ne s'est pas encore connecté, on réessaiera.
        if (!e.message.contains('code invalide')) rethrow;
      }
    }
    if (changed) await store.saveFriends();
  }

  /// Récupère les potes (et leur position) depuis le serveur.
  Future<void> _pullFriends() async {
    final rows = await _db
        .from('profiles')
        .select('id, ble_id, name, lat, lon, location_at');
    final seen = <String>{};
    var added = false;
    for (final r in rows) {
      final serverId = r['id'] as String;
      if (serverId == myServerId) continue;
      final ble = (r['ble_id'] as String).toLowerCase();
      if (store.removed.contains(ble)) continue;
      seen.add(ble);
      var f = store.friendByBle(ble);
      if (f == null) {
        // Quelqu'un t'a ajouté : on l'ajoute aussi pour le radar Bluetooth.
        f = Friend(id: ble, name: r['name'] as String? ?? 'Pote', linked: true);
        store.friends.add(f);
        added = true;
      }
      f.serverId = serverId;
      f.linked = true;
      f.name = r['name'] as String? ?? f.name;
      f.lat = (r['lat'] as num?)?.toDouble();
      f.lon = (r['lon'] as num?)?.toDouble();
      f.locationAt =
          DateTime.tryParse(r['location_at'] as String? ?? '')?.toLocal();
    }
    for (final f in store.friends) {
      if (!seen.contains(f.id)) {
        f.lat = null;
        f.lon = null;
        f.locationAt = null;
      }
    }
    await store.saveFriends();
    if (added) await radar.friendsChanged();
  }

  Future<void> friendAdded(Friend f) async {
    store.removed.remove(f.id);
    await store.saveRemoved();
    unawaited(sync());
  }

  Future<void> unlink(Friend f) async {
    store.removed.add(f.id);
    await store.saveRemoved();
    final me = myServerId;
    final them = f.serverId;
    if (!_initialized || me == null || them == null) return;
    try {
      await _db.from('friendships').delete().eq('user_id', me).eq('friend_id', them);
      await _db.from('friendships').delete().eq('user_id', them).eq('friend_id', me);
    } catch (e) {
      debugPrint('Retrait : $e');
    }
  }

  Friend? friendByServerId(String id) {
    for (final f in store.friends) {
      if (f.serverId == id) return f;
    }
    return null;
  }

  // ---------------------------------------------------------------------------
  // Chat
  // ---------------------------------------------------------------------------

  void _listenMessages() {
    _msgSub?.cancel();
    _msgAlive = true;
    _msgSub = _db
        .from('messages')
        .stream(primaryKey: ['id'])
        .order('created_at', ascending: true)
        .listen(
          _onMessages,
          onError: (Object e) {
            debugPrint('Messages : $e');
            _msgAlive = false;
          },
          onDone: () => _msgAlive = false,
        );
  }

  void _onMessages(List<Map<String, dynamic>> rows) {
    final list = rows.map(ChatMessage.fromRow).toList()
      ..sort((a, b) => a.id.compareTo(b.id));
    final previousMax = _maxSeenId;
    _maxSeenId = max(previousMax ?? 0, list.isEmpty ? 0 : list.last.id);
    if (previousMax != null) {
      for (final m in list) {
        if (m.id > previousMax && m.sender != myServerId && m.sender != openChat) {
          final f = friendByServerId(m.sender);
          unawaited(radar.notify(m.id, f?.name ?? 'Nouveau message', m.body));
        }
      }
    }
    messages = list;
    notifyListeners();
  }

  List<ChatMessage> conversation(Friend f) {
    final id = f.serverId;
    if (id == null) return const [];
    return messages.where((m) => m.sender == id || m.recipient == id).toList();
  }

  ChatMessage? lastMessageWith(Friend f) {
    final c = conversation(f);
    return c.isEmpty ? null : c.last;
  }

  int unreadWith(Friend f) {
    final id = f.serverId;
    if (id == null) return 0;
    final read = store.lastRead[id] ?? 0;
    return messages.where((m) => m.sender == id && m.id > read).length;
  }

  int get totalUnread =>
      store.friends.fold(0, (sum, f) => sum + unreadWith(f));

  void markRead(Friend f) {
    final id = f.serverId;
    final c = conversation(f);
    if (id == null || c.isEmpty) return;
    if ((store.lastRead[id] ?? 0) >= c.last.id) return;
    store.lastRead[id] = c.last.id;
    unawaited(store.saveLastRead());
    notifyListeners();
  }

  Future<bool> send(Friend f, String body) async {
    final to = f.serverId;
    if (!_initialized || to == null) return false;
    try {
      final row = await _db
          .from('messages')
          .insert({'recipient': to, 'body': body})
          .select()
          .single();
      final m = ChatMessage.fromRow(row);
      if (!messages.any((x) => x.id == m.id)) messages = [...messages, m];
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Envoi : $e');
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Position
  // ---------------------------------------------------------------------------

  Future<String?> _checkLocation() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      return 'Active la localisation (GPS) du téléphone.';
    }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      return 'Autorise Festipote à accéder à ta position.';
    }
    return null;
  }

  /// Trouve ma position (sans la partager).
  Future<String?> locateMe() async {
    final err = await _checkLocation();
    if (err != null) return err;
    try {
      myPosition ??= await Geolocator.getLastKnownPosition();
      notifyListeners();
      myPosition = await Geolocator.getCurrentPosition(
        locationSettings: LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 20),
        ),
      );
      notifyListeners();
      return null;
    } catch (_) {
      return myPosition == null ? 'Position introuvable pour l\'instant.' : null;
    }
  }

  Future<String?> startSharing() async {
    final err = await _checkLocation();
    if (err != null) return err;
    await _posSub?.cancel();
    final LocationSettings settings = defaultTargetPlatform == TargetPlatform.android
        ? AndroidSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 15,
            intervalDuration: const Duration(seconds: 20),
            // Notification permanente : garde l'appli active écran éteint.
            foregroundNotificationConfig: ForegroundNotificationConfig(
              notificationTitle: 'Festipote partage ta position',
              notificationText: 'Tes potes te voient sur la carte.',
              enableWakeLock: true,
            ),
          )
        : LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 15);
    _posSub = Geolocator.getPositionStream(locationSettings: settings)
        .listen(_onPosition, onError: (Object e) => debugPrint('GPS : $e'));
    await store.setSharing(true);
    notifyListeners();
    return null;
  }

  Future<void> stopSharing() async {
    await _posSub?.cancel();
    _posSub = null;
    await store.setSharing(false);
    notifyListeners();
    final me = myServerId;
    if (!_initialized || me == null) return;
    try {
      await _db
          .from('profiles')
          .update({'lat': null, 'lon': null, 'location_at': null}).eq('id', me);
    } catch (_) {}
  }

  void _onPosition(Position p) {
    myPosition = p;
    notifyListeners();
    if (DateTime.now().difference(_lastUpload) > const Duration(seconds: 20)) {
      unawaited(_upload());
    }
  }

  /// Renvoie la position de temps en temps même sans bouger,
  /// pour ne pas disparaître de la carte de tes potes.
  Future<void> _heartbeat() async {
    if (sharing &&
        DateTime.now().difference(_lastUpload) > const Duration(minutes: 5)) {
      await _upload();
    }
  }

  Future<void> _upload() async {
    final p = myPosition;
    final me = myServerId;
    if (!_initialized || !_profilePushed || p == null || me == null) return;
    _lastUpload = DateTime.now();
    try {
      await _db.from('profiles').update({
        'lat': p.latitude,
        'lon': p.longitude,
        'location_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', me);
    } catch (e) {
      debugPrint('Envoi position : $e');
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _msgSub?.cancel();
    _posSub?.cancel();
    super.dispose();
  }
}
