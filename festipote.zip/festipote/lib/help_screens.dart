import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

import 'cloud.dart';
import 'duel_models.dart';
import 'main.dart' show kRed;
import 'store.dart';

Future<void> _call(String number) =>
    launchUrl(Uri(scheme: 'tel', path: number)).then((_) {}, onError: (_) {});

Future<void> _sms(String number) =>
    launchUrl(Uri(scheme: 'sms', path: number)).then((_) {}, onError: (_) {});

// =============================================================================
// « J'ai besoin d'aide »
// =============================================================================

class HelpScreen extends StatefulWidget {
  const HelpScreen({super.key, required this.cloud});

  final Cloud cloud;

  @override
  State<HelpScreen> createState() => _HelpScreenState();
}

class _HelpScreenState extends State<HelpScreen> {
  String? _kind;
  final _msg = TextEditingController();
  bool _sending = false;

  @override
  void dispose() {
    _msg.dispose();
    super.dispose();
  }

  void _snack(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _send() async {
    final kind = _kind;
    if (kind == null || _sending) return;
    setState(() => _sending = true);
    final err = await widget.cloud.sendHelp(kind, _msg.text);
    if (!mounted) return;
    setState(() => _sending = false);
    if (err != null) _snack(err);
  }

  Future<void> _alertFriends() async {
    setState(() => _sending = true);
    final n = await widget.cloud.alertFriends();
    if (!mounted) return;
    setState(() => _sending = false);
    _snack(n == 0
        ? 'Aucun pote prévenu : pas de réseau ou pas de pote relié.'
        : '$n pote${n > 1 ? 's' : ''} prévenu${n > 1 ? 's' : ''} par le chat.');
  }

  @override
  Widget build(BuildContext context) {
    final cloud = widget.cloud;
    return Scaffold(
      appBar: AppBar(title: const Text('Besoin d\'aide')),
      body: ListenableBuilder(
        listenable: cloud,
        builder: (context, _) {
          final mine = cloud.myActiveHelp;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const _EmergencyCard(),
              const SizedBox(height: 20),
              if (mine != null)
                _MyHelpStatus(help: mine, cloud: cloud)
              else if (cloud.event != null)
                ..._form(cloud.event!)
              else
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Text(
                    'Tu n\'es dans aucune soirée, donc aucun bénévole ne peut être '
                    'prévenu. Tu peux prévenir tes potes ci-dessous.',
                    style: TextStyle(color: Colors.white70),
                  ),
                ),
              const SizedBox(height: 24),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                onPressed: _sending ? null : _alertFriends,
                icon: const Icon(Icons.group),
                label: const Text('Prévenir mes potes (message + position)'),
              ),
            ],
          );
        },
      ),
    );
  }

  List<Widget> _form(EventInfo e) => [
        Text('Alerter les bénévoles de ${e.name}',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text(
          e.volunteerCount == 0
              ? 'Aucun bénévole connecté pour l\'instant, l\'alerte leur arrivera dès leur arrivée.'
              : '${e.volunteerCount} bénévole${e.volunteerCount > 1 ? 's' : ''} recevr${e.volunteerCount > 1 ? 'ont' : 'a'} ton alerte, avec ta position.',
          style: const TextStyle(color: Colors.white70),
        ),
        const SizedBox(height: 16),
        for (final entry in helpKinds.entries)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Material(
              color: _kind == entry.key ? kRed : Colors.white10,
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => setState(() => _kind = entry.key),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  child: Row(
                    children: [
                      Text(entry.value.$1, style: const TextStyle(fontSize: 26)),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Text(entry.value.$2,
                            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                      ),
                      if (_kind == entry.key) const Icon(Icons.check_circle),
                    ],
                  ),
                ),
              ),
            ),
          ),
        const SizedBox(height: 8),
        TextField(
          controller: _msg,
          maxLines: 2,
          maxLength: 300,
          decoration: const InputDecoration(
            hintText: 'Où es-tu ? Que se passe-t-il ? (facultatif)',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          style: FilledButton.styleFrom(
            backgroundColor: kRed,
            minimumSize: const Size.fromHeight(60),
            textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
          ),
          onPressed: _kind == null || _sending ? null : _send,
          icon: _sending
              ? const SizedBox(
                  width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 3))
              : const Icon(Icons.campaign),
          label: Text(_kind == null ? 'Choisis ce qui se passe' : 'Envoyer l\'alerte'),
        ),
      ];
}

class _EmergencyCard extends StatelessWidget {
  const _EmergencyCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white24),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text('Urgence vitale, danger immédiat ?',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text('Appelle les secours d\'abord, les bénévoles ensuite.',
              style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      minimumSize: const Size.fromHeight(52)),
                  onPressed: () => _call('112'),
                  icon: const Icon(Icons.call),
                  label: const Text('Appeler le 112',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                  onPressed: () => _sms('114'),
                  icon: const Icon(Icons.sms),
                  label: const Text('SMS au 114'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          const Text('Le 114 reçoit les SMS si tu ne peux pas parler.',
              style: TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      ),
    );
  }
}

class _MyHelpStatus extends StatelessWidget {
  const _MyHelpStatus({required this.help, required this.cloud});

  final HelpRequest help;
  final Cloud cloud;

  @override
  Widget build(BuildContext context) {
    final taken = help.status == 'taken';
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: taken ? const Color(0xFF123A1E) : const Color(0xFF3A0A0D),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: taken ? Colors.greenAccent : kRed, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(taken ? '🙌' : '📣', style: const TextStyle(fontSize: 48), textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Text(
            taken
                ? '${help.takenByName ?? 'Un bénévole'} arrive'
                : 'Alerte envoyée aux bénévoles',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 6),
          Text(
            taken
                ? 'Reste où tu es si tu peux. Tu seras prévenu·e si ça change.'
                : '${helpLabel(help.kind)}, ${timeAgo(help.createdAt)}. '
                    'Tu recevras une notification dès qu\'un bénévole la prend.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 18),
          FilledButton(
            style: FilledButton.styleFrom(
                backgroundColor: Colors.white, foregroundColor: Colors.black,
                minimumSize: const Size.fromHeight(50)),
            onPressed: () async {
              final err = await cloud.resolveHelp(help.id);
              if (err != null && context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
              }
            },
            child: Text(taken ? 'C\'est réglé, merci' : 'Tout va bien, annuler l\'alerte'),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// Écran des bénévoles
// =============================================================================

class VolunteerScreen extends StatelessWidget {
  const VolunteerScreen({super.key, required this.cloud});

  final Cloud cloud;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🦺 Alertes bénévoles')),
      body: ListenableBuilder(
        listenable: cloud,
        builder: (context, _) {
          final all = cloud.volunteerAlerts;
          final active = all.where((h) => h.isActive).toList();
          final done = all.where((h) => !h.isActive).take(15).toList();
          if (all.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Aucune alerte pour l\'instant. Ton téléphone sonnera et vibrera fort '
                  'si quelqu\'un a besoin d\'aide.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70),
                ),
              ),
            );
          }
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              for (final h in active) _AlertCard(help: h, cloud: cloud),
              if (done.isNotEmpty) ...[
                const Padding(
                  padding: EdgeInsets.fromLTRB(8, 20, 8, 6),
                  child: Text('Terminées', style: TextStyle(color: Colors.white54)),
                ),
                for (final h in done) _AlertCard(help: h, cloud: cloud),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _AlertCard extends StatelessWidget {
  const _AlertCard({required this.help, required this.cloud});

  final HelpRequest help;
  final Cloud cloud;

  Future<void> _act(BuildContext context, Future<String?> Function() action) async {
    final err = await action();
    if (err != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = cloud.myServerId;
    final mine = help.takenBy == me;
    final pos = cloud.myPosition;
    String? distance;
    if (help.lat != null && help.lon != null && pos != null) {
      final m = Geolocator.distanceBetween(pos.latitude, pos.longitude, help.lat!, help.lon!);
      distance = m < 1000 ? 'à ~${m.round()} m' : 'à ~${(m / 1000).toStringAsFixed(1)} km';
    }
    final statusText = switch (help.status) {
      'open' => 'En attente d\'un bénévole',
      'taken' => mine ? 'Tu y vas' : 'Pris en charge par ${help.takenByName ?? 'un bénévole'}',
      'resolved' => 'Réglé',
      _ => 'Annulée par la personne',
    };
    return Card(
      color: help.status == 'open' ? const Color(0xFF3A0A0D) : null,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: help.status == 'open' ? kRed : Colors.white12, width: 1.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(helpEmoji(help.kind), style: const TextStyle(fontSize: 28)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(help.requesterName,
                          style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                      Text('${helpLabel(help.kind)}, ${timeAgo(help.createdAt)}',
                          style: const TextStyle(color: Colors.white70)),
                      if (help.fromWeb)
                        const Text('🌐 Envoyée depuis la page web (sans l\'appli)',
                            style: TextStyle(color: Colors.white54, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
            if (help.message != null) ...[
              const SizedBox(height: 10),
              Text('« ${help.message} »', style: const TextStyle(fontSize: 16)),
            ],
            const SizedBox(height: 10),
            if (help.nearVolunteers != null)
              Text('📡 Captée près de : ${help.nearVolunteers}',
                  style: const TextStyle(color: Colors.white70)),
            if (help.lat != null)
              Text(
                '📍 Position GPS${distance != null ? ', $distance' : ''}'
                '${help.accuracy != null ? ' (précision ±${help.accuracy!.round()} m)' : ''}',
                style: const TextStyle(color: Colors.white70),
              ),
            const SizedBox(height: 6),
            Text(statusText, style: const TextStyle(fontWeight: FontWeight.w700)),
            if (help.isActive) ...[
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (help.status == 'open')
                    FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: kRed),
                      onPressed: () => _act(context, () => cloud.takeHelp(help.id)),
                      icon: const Icon(Icons.directions_run),
                      label: const Text('J\'y vais'),
                    ),
                  if (help.lat != null)
                    OutlinedButton.icon(
                      onPressed: () => launchUrl(
                        Uri.parse('geo:${help.lat},${help.lon}?q=${help.lat},${help.lon}'),
                      ).then((_) {}, onError: (_) {}),
                      icon: const Icon(Icons.map),
                      label: const Text('Itinéraire'),
                    ),
                  OutlinedButton.icon(
                    onPressed: () => _act(context, () => cloud.resolveHelp(help.id)),
                    icon: const Icon(Icons.check),
                    label: const Text('Réglé'),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
