import 'dart:math';

import 'package:flutter/material.dart';

import 'cloud.dart';
import 'duel_models.dart';
import 'main.dart' show kRed;
import 'radar.dart';
import 'store.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({
    super.key,
    required this.store,
    required this.radar,
    required this.cloud,
  });

  final Store store;
  final Radar radar;
  final Cloud cloud;

  String _nameOf(String bleId) => store.friendByBle(bleId)?.name ?? 'Ancien pote';

  Future<void> _reset(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Remettre les stats à zéro ?'),
        content: const Text('Tous les croisements enregistrés seront effacés.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Effacer'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await store.clearEncounters();
      radar.refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Stats'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep_outlined),
            tooltip: 'Remettre à zéro',
            onPressed: () => _reset(context),
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: Listenable.merge([radar, cloud]),
        builder: (context, _) {
          final text = Theme.of(context).textTheme;
          final enc = store.encounters;
          final now = DateTime.now();
          final today = enc.where((e) => sameDay(e.time, now)).length;
          final counts = <String, int>{};
          for (final e in enc) {
            counts[e.friendId] = (counts[e.friendId] ?? 0) + 1;
          }
          final top = counts.entries.toList()
            ..sort((a, b) => b.value.compareTo(a.value));
          final hours = List<int>.filled(24, 0);
          for (final e in enc) {
            hours[e.time.hour]++;
          }
          final maxHour = hours.reduce(max);
          final peakHour = maxHour == 0 ? null : hours.indexOf(maxHour);

          // Records par jour
          final perDay = <DateTime, int>{};
          for (final e in enc) {
            final day = DateTime(e.time.year, e.time.month, e.time.day);
            perDay[day] = (perDay[day] ?? 0) + 1;
          }
          final bestDay = perDay.isEmpty
              ? null
              : perDay.entries.reduce((a, b) => b.value > a.value ? b : a);
          final todayCounts = <String, int>{};
          for (final e in enc.where((e) => sameDay(e.time, now))) {
            todayCounts[e.friendId] = (todayCounts[e.friendId] ?? 0) + 1;
          }
          final friendOfDay = todayCounts.isEmpty
              ? null
              : todayCounts.entries.reduce((a, b) => b.value > a.value ? b : a);

          final showDuels = Cloud.configured && cloud.duelsAvailable;
          final ds = cloud.myDuelStats;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                children: [
                  Expanded(child: _StatCard('${enc.length}', 'croisements')),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _StatCard('${counts.length}',
                        counts.length > 1 ? 'potes croisés' : 'pote croisé'),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: _StatCard('$today', 'aujourd\'hui')),
                ],
              ),
              if (showDuels && ds.played + ds.draws > 0) ...[
                const SizedBox(height: 28),
                Text('⚔️ Duels', style: text.titleMedium),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: _StatCard('${ds.wins}', 'victoires')),
                    const SizedBox(width: 10),
                    Expanded(child: _StatCard('${ds.losses}', 'défaites')),
                    const SizedBox(width: 10),
                    Expanded(
                        child: _StatCard('${(ds.winRate * 100).round()} %', 'de victoires')),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                        child: _StatCard(
                            ds.best == null ? '–' : formatDuration(ds.best!), 'meilleure réaction')),
                    const SizedBox(width: 10),
                    Expanded(
                        child: _StatCard(ds.average == null ? '–' : formatDuration(ds.average!),
                            'réaction moyenne')),
                    const SizedBox(width: 10),
                    Expanded(child: _StatCard('${ds.bestStreak}', 'meilleure série')),
                  ],
                ),
                const SizedBox(height: 10),
                if (ds.rival != null)
                  _Line('🤺', 'Ton rival', '${cloud.nameOf(ds.rival!)} (${ds.rivalCount} duels)'),
                if (ds.nemesis != null)
                  _Line('😈', 'Ta némésis',
                      '${cloud.nameOf(ds.nemesis!)} (t\'a battu ${ds.nemesisCount}×)'),
                if (ds.victim != null)
                  _Line('🎯', 'Ta victime préférée',
                      '${cloud.nameOf(ds.victim!)} (battu·e ${ds.victimCount}×)'),
                if (ds.draws > 0) _Line('🤝', 'Matchs nuls', '${ds.draws}'),
              ],
              const SizedBox(height: 28),
              if (enc.isEmpty)
                const Text(
                  'Active le mode festival : chaque fois que tu croises un '
                  'pote, ça s\'ajoute ici.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70),
                )
              else ...[
                Text('Tes potes les plus croisés', style: text.titleMedium),
                const SizedBox(height: 4),
                for (final (i, e) in top.take(5).indexed)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      backgroundColor: i == 0 ? kRed : Colors.white12,
                      foregroundColor: Colors.white,
                      child: Text('${i + 1}'),
                    ),
                    title: Text(_nameOf(e.key)),
                    trailing: Text('${e.value} ×',
                        style: text.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w800)),
                  ),
                const SizedBox(height: 24),
                Text('À quelle heure tu croises tes potes',
                    style: text.titleMedium),
                const SizedBox(height: 14),
                SizedBox(
                  height: 130,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      for (var h = 0; h < 24; h++)
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 1.5),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                  height: maxHour == 0
                                      ? 0.0
                                      : 100.0 * hours[h] / maxHour,
                                  decoration: const BoxDecoration(
                                    color: kRed,
                                    borderRadius: BorderRadius.vertical(
                                        top: Radius.circular(3)),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  h % 6 == 0 ? '${h}h' : '',
                                  softWrap: false,
                                  overflow: TextOverflow.visible,
                                  style: const TextStyle(
                                      fontSize: 10, color: Colors.white54),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 28),
                Text('Records', style: text.titleMedium),
                const SizedBox(height: 8),
                if (bestDay != null)
                  _Line('📅', 'Record en une journée',
                      '${bestDay.value} croisements le ${bestDay.key.day.toString().padLeft(2, '0')}/${bestDay.key.month.toString().padLeft(2, '0')}'),
                _Line('🎪', 'Jours avec des croisements', '${perDay.length}'),
                if (peakHour != null)
                  _Line('⏰', 'Heure de pointe', 'entre ${peakHour}h et ${(peakHour + 1) % 24}h'),
                if (friendOfDay != null)
                  _Line('⭐', 'Pote du jour',
                      '${_nameOf(friendOfDay.key)} (${friendOfDay.value}×)'),
                const SizedBox(height: 24),
                Text(
                  'Dernier croisement : ${_nameOf(enc.last.friendId)} '
                  '${formatSeen(enc.last.time)}',
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard(this.value, this.label);

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              value,
              maxLines: 1,
              style: const TextStyle(
                  fontSize: 30, fontWeight: FontWeight.w900, color: kRed),
            ),
          ),
          const SizedBox(height: 2),
          Text(label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, color: Colors.white70)),
        ],
      ),
    );
  }
}

class _Line extends StatelessWidget {
  const _Line(this.icon, this.label, this.value);

  final String icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Text(icon, style: const TextStyle(fontSize: 20)),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: const TextStyle(color: Colors.white70))),
          const SizedBox(width: 8),
          Flexible(
            child: Text(value,
                textAlign: TextAlign.right,
                style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}
