DateTime? _time(dynamic v) =>
    v == null ? null : DateTime.tryParse(v as String)?.toLocal();

enum DuelOutcome { pending, won, lost, draw }

class Duel {
  Duel({
    required this.id,
    required this.playerA,
    required this.playerB,
    required this.createdAt,
    required this.expiresAt,
    this.winner,
    this.wonAt,
    this.aTappedAt,
    this.bTappedAt,
  });

  final int id;
  final String playerA; // celui qui a lancé le duel
  final String playerB;
  final DateTime createdAt;
  final DateTime expiresAt;
  final String? winner;
  final DateTime? wonAt;
  final DateTime? aTappedAt;
  final DateTime? bTappedAt;

  factory Duel.fromRow(Map<String, dynamic> r) => Duel(
        id: (r['id'] as num).toInt(),
        playerA: r['player_a'] as String,
        playerB: r['player_b'] as String,
        createdAt: _time(r['created_at']) ?? DateTime.now(),
        expiresAt: _time(r['expires_at']) ?? DateTime.now(),
        winner: r['winner'] as String?,
        wonAt: _time(r['won_at']),
        aTappedAt: _time(r['a_tapped_at']),
        bTappedAt: _time(r['b_tapped_at']),
      );

  bool involves(String id) => playerA == id || playerB == id;
  String opponentOf(String me) => playerA == me ? playerB : playerA;
  DateTime? tapOf(String me) => playerA == me ? aTappedAt : bTappedAt;

  Duration get remaining => expiresAt.difference(DateTime.now());
  bool get resolved => winner != null;
  bool get isLive => !resolved && remaining > Duration.zero;

  /// Temps mis par le gagnant pour appuyer, depuis le début du duel.
  Duration? get winnerTime => wonAt?.difference(createdAt);
  Duration? timeOf(String me) => tapOf(me)?.difference(createdAt);

  DuelOutcome outcomeFor(String me) {
    if (winner != null) return winner == me ? DuelOutcome.won : DuelOutcome.lost;
    return remaining > Duration.zero ? DuelOutcome.pending : DuelOutcome.draw;
  }
}

class LeaderRow {
  LeaderRow({
    required this.userId,
    required this.name,
    required this.wins,
    required this.losses,
    required this.draws,
    required this.encounters,
    this.bestMs,
    this.avgMs,
  });

  final String userId;
  final String name;
  final int wins;
  final int losses;
  final int draws;
  final int encounters;
  final int? bestMs;
  final int? avgMs;

  int get played => wins + losses;
  double get winRate => played == 0 ? 0 : wins / played;

  static int _int(dynamic v) => (v as num?)?.toInt() ?? 0;

  factory LeaderRow.fromRow(Map<String, dynamic> r) => LeaderRow(
        userId: r['user_id'] as String,
        name: r['name'] as String? ?? 'Pote',
        wins: _int(r['wins']),
        losses: _int(r['losses']),
        draws: _int(r['draws']),
        encounters: _int(r['encounters']),
        bestMs: (r['best_ms'] as num?)?.toInt(),
        avgMs: (r['avg_ms'] as num?)?.toInt(),
      );
}

/// Mes statistiques de duel, calculées à partir de l'historique.
class DuelStats {
  int wins = 0;
  int losses = 0;
  int draws = 0;
  int streak = 0; // série de victoires en cours
  int bestStreak = 0;
  Duration? best; // réaction la plus rapide
  Duration? average;
  String? rival; // pote le plus affronté
  int rivalCount = 0;
  String? nemesis; // celui qui te bat le plus
  int nemesisCount = 0;
  String? victim; // celui que tu bats le plus
  int victimCount = 0;

  int get played => wins + losses;
  double get winRate => played == 0 ? 0 : wins / played;

  static DuelStats compute(List<Duel> duels, String me) {
    final s = DuelStats();
    final sorted = [...duels]..sort((a, b) => a.id.compareTo(b.id));
    final faced = <String, int>{};
    final beatMe = <String, int>{};
    final iBeat = <String, int>{};
    final times = <Duration>[];
    var current = 0;

    for (final d in sorted) {
      if (!d.involves(me)) continue;
      final outcome = d.outcomeFor(me);
      if (outcome == DuelOutcome.pending) continue;
      final opp = d.opponentOf(me);
      faced[opp] = (faced[opp] ?? 0) + 1;
      switch (outcome) {
        case DuelOutcome.won:
          s.wins++;
          current++;
          if (current > s.bestStreak) s.bestStreak = current;
          iBeat[opp] = (iBeat[opp] ?? 0) + 1;
          final t = d.winnerTime;
          if (t != null && !t.isNegative) times.add(t);
        case DuelOutcome.lost:
          s.losses++;
          current = 0;
          beatMe[opp] = (beatMe[opp] ?? 0) + 1;
        case DuelOutcome.draw:
          s.draws++;
        case DuelOutcome.pending:
          break;
      }
    }
    s.streak = current;

    if (times.isNotEmpty) {
      times.sort();
      s.best = times.first;
      final total = times.fold<int>(0, (sum, t) => sum + t.inMilliseconds);
      s.average = Duration(milliseconds: total ~/ times.length);
    }

    MapEntry<String, int>? top(Map<String, int> m) => m.isEmpty
        ? null
        : m.entries.reduce((a, b) => b.value > a.value ? b : a);
    final r = top(faced);
    if (r != null) {
      s.rival = r.key;
      s.rivalCount = r.value;
    }
    final n = top(beatMe);
    if (n != null) {
      s.nemesis = n.key;
      s.nemesisCount = n.value;
    }
    final v = top(iBeat);
    if (v != null) {
      s.victim = v.key;
      s.victimCount = v.value;
    }
    return s;
  }
}

/// « 2,4 s » ou « 1 min 05 ».
String formatDuration(Duration d) {
  if (d.inSeconds < 60) {
    return '${(d.inMilliseconds / 1000).toStringAsFixed(1).replaceAll('.', ',')} s';
  }
  final s = (d.inSeconds % 60).toString().padLeft(2, '0');
  return '${d.inMinutes} min $s';
}

/// Une soirée (mode soirée), telle que renvoyée par le serveur.
class EventInfo {
  EventInfo({
    required this.id,
    required this.name,
    required this.joinCode,
    required this.active,
    required this.paused,
    required this.rssi,
    required this.dwellSec,
    required this.pairCooldownMin,
    required this.userCooldownMin,
    required this.duelWindowSec,
    required this.myNum,
    required this.nameByUser,
    required this.isVolunteer,
    required this.volunteerNums,
  });

  final String id;
  final String name;
  final String joinCode;
  final bool active;
  final bool paused;
  final int rssi;
  final int dwellSec;
  final int pairCooldownMin;
  final int userCooldownMin;
  final int duelWindowSec;
  final int? myNum;
  final Map<String, String> nameByUser;
  final bool isVolunteer; // moi
  final Set<int> volunteerNums;

  int get volunteerCount => volunteerNums.length;

  int get memberCount => nameByUser.length;

  static int _int(dynamic v, int fallback) => (v as num?)?.toInt() ?? fallback;

  factory EventInfo.fromJson(Map<String, dynamic> j) {
    final names = <String, String>{};
    final volunteers = <int>{};
    for (final m in (j['members'] as List? ?? const [])) {
      final row = Map<String, dynamic>.from(m as Map);
      names[row['user_id'] as String] = row['name'] as String? ?? 'Participant';
      if (row['volunteer'] == true) volunteers.add((row['num'] as num).toInt());
    }
    return EventInfo(
      id: j['id'] as String,
      name: j['name'] as String? ?? 'Soirée',
      joinCode: j['join_code'] as String? ?? '',
      active: j['active'] == true,
      paused: j['paused'] == true,
      rssi: _int(j['rssi_threshold'], -65),
      dwellSec: _int(j['dwell_seconds'], 20),
      pairCooldownMin: _int(j['pair_cooldown_min'], 45),
      userCooldownMin: _int(j['user_cooldown_min'], 8),
      duelWindowSec: _int(j['duel_window_sec'], 60),
      myNum: (j['me'] as num?)?.toInt(),
      nameByUser: names,
      isVolunteer: j['volunteer'] == true,
      volunteerNums: volunteers,
    );
  }
}

/// Lit un code de soirée (QR « festipote-event:ABC123 » ou code tapé).
String? parseEventCode(String raw) {
  final text = raw.trim();
  final m = RegExp(r'festipote-event:([A-Za-z0-9]{4,10})').firstMatch(text);
  if (m != null) return m.group(1)!.toUpperCase();
  if (RegExp(r'^[A-Za-z0-9]{4,10}$').hasMatch(text)) return text.toUpperCase();
  return null;
}

// --- Appels à l'aide -----------------------------------------------------------

const helpKinds = <String, (String, String)>{
  'sante': ('🩹', 'Malaise ou blessure'),
  'agression': ('🛑', 'Harcèlement ou agression'),
  'perdu': ('🧭', 'Perdu·e, besoin qu\'on vienne'),
  'autre': ('💬', 'Autre problème'),
};

String helpEmoji(String kind) => helpKinds[kind]?.$1 ?? '🆘';
String helpLabel(String kind) => helpKinds[kind]?.$2 ?? 'Besoin d\'aide';

class HelpRequest {
  HelpRequest({
    required this.id,
    required this.eventId,
    required this.requester,
    required this.requesterName,
    required this.kind,
    required this.createdAt,
    required this.status,
    this.fromWeb = false,
    this.message,
    this.lat,
    this.lon,
    this.accuracy,
    this.nearVolunteers,
    this.takenBy,
    this.takenByName,
  });

  final int id;
  final String eventId;
  final String? requester; // null = alerte envoyée depuis la page web
  final String requesterName;
  final bool fromWeb;
  final String kind;
  final DateTime createdAt;
  final String status; // open, taken, resolved, cancelled
  final String? message;
  final double? lat;
  final double? lon;
  final double? accuracy;
  final String? nearVolunteers;
  final String? takenBy;
  final String? takenByName;

  bool get isActive => status == 'open' || status == 'taken';

  factory HelpRequest.fromRow(Map<String, dynamic> r) => HelpRequest(
        id: (r['id'] as num).toInt(),
        eventId: r['event_id'] as String,
        requester: r['requester'] as String?,
        fromWeb: r['source'] == 'web',
        requesterName: r['requester_name'] as String? ?? 'Participant',
        kind: r['kind'] as String? ?? 'autre',
        createdAt: _time(r['created_at']) ?? DateTime.now(),
        status: r['status'] as String? ?? 'open',
        message: r['message'] as String?,
        lat: (r['lat'] as num?)?.toDouble(),
        lon: (r['lon'] as num?)?.toDouble(),
        accuracy: (r['accuracy_m'] as num?)?.toDouble(),
        nearVolunteers: r['near_volunteers'] as String?,
        takenBy: r['taken_by'] as String?,
        takenByName: r['taken_by_name'] as String?,
      );
}
