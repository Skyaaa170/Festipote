import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:qr_flutter/qr_flutter.dart';

import 'build_info.dart';
import 'chat_screens.dart';
import 'cloud.dart';
import 'main.dart' show kRed;
import 'radar.dart';
import 'shell.dart';
import 'store.dart';

// ---------------------------------------------------------------------------
// Premier lancement : choisir son prénom / pseudo
// ---------------------------------------------------------------------------

class NameScreen extends StatefulWidget {
  const NameScreen({
    super.key,
    required this.store,
    required this.radar,
    required this.cloud,
  });

  final Store store;
  final Radar radar;
  final Cloud cloud;

  @override
  State<NameScreen> createState() => _NameScreenState();
}

class _NameScreenState extends State<NameScreen> {
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _ctrl.text.trim();
    if (name.isEmpty) return;
    await widget.store.setMyName(name);
    unawaited(widget.cloud.refreshProfile());
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => Shell(
          store: widget.store, radar: widget.radar, cloud: widget.cloud),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Festipote',
                  style: text.displaySmall
                      ?.copyWith(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('Ton téléphone vibre quand tu croises tes potes.',
                  style: text.bodyLarge),
              const SizedBox(height: 40),
              TextField(
                controller: _ctrl,
                autofocus: true,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(
                  labelText: 'Ton prénom ou pseudo',
                  border: OutlineInputBorder(),
                ),
                onSubmitted: (_) => _save(),
              ),
              const SizedBox(height: 16),
              FilledButton(onPressed: _save, child: const Text('Continuer')),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Accueil
// ---------------------------------------------------------------------------

class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
    required this.store,
    required this.radar,
    required this.cloud,
  });

  final Store store;
  final Radar radar;
  final Cloud cloud;

  Future<void> _addFriend(BuildContext context) async {
    final friend = await Navigator.of(context).push<Friend>(
      MaterialPageRoute(builder: (_) => const ScanScreen()),
    );
    if (friend == null || !context.mounted) return;

    String message;
    final existing = store.friendByBle(friend.id);
    if (friend.id == store.myId) {
      message = 'C\'est ton propre code 😅';
    } else if (existing != null) {
      // Déjà là : on récupère au moins son code pour le relier en ligne.
      if (friend.code != null && existing.code != friend.code) {
        existing.code = friend.code;
        existing.linked = false;
        await store.saveFriends();
        await cloud.friendAdded(existing);
      }
      message = '${existing.name} est déjà dans ta liste';
    } else {
      store.friends.add(friend);
      await store.saveFriends();
      await radar.friendsChanged();
      await cloud.friendAdded(friend);
      message = '${friend.name} ajouté·e';
    }
    if (!context.mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _removeFriend(Friend friend) async {
    store.friends.removeWhere((f) => f.id == friend.id);
    await radar.friendsChanged();
    await store.saveFriends();
    await cloud.unlink(friend);
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Festipote',
            style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code),
            tooltip: 'Mon QR code',
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => MyQrScreen(store: store),
            )),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addFriend(context),
        icon: const Icon(Icons.qr_code_scanner),
        label: const Text('Ajouter un pote'),
      ),
      body: ListenableBuilder(
        listenable: Listenable.merge([radar, cloud]),
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
          children: [
            _RadarCard(radar: radar),
            const SizedBox(height: 28),
            Text('Distance de détection', style: text.titleMedium),
            const SizedBox(height: 10),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: -70, label: Text('Proche')),
                ButtonSegment(value: -80, label: Text('Moyen')),
                ButtonSegment(value: -90, label: Text('Large')),
              ],
              selected: {store.rssiThreshold},
              showSelectedIcon: false,
              onSelectionChanged: (s) => radar.setRange(s.first),
            ),
            const SizedBox(height: 6),
            Text(
              'Environ 5, 15 ou 30 mètres. La foule absorbe beaucoup le '
              'Bluetooth, donc c\'est indicatif.',
              style: text.bodySmall?.copyWith(color: Colors.white60),
            ),
            const SizedBox(height: 28),
            Text('Mes potes (${store.friends.length})',
                style: text.titleMedium),
            const SizedBox(height: 4),
            if (store.friends.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Text(
                  'Ajoute tes potes avec le bouton en bas (QR code ou code '
                  'reçu par message). Pour qu\'iels t\'ajoutent, montre-leur '
                  'ton QR code ou envoie-leur ton code (icône en haut à droite).',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70),
                ),
              ),
            for (final f in store.friends)
              Dismissible(
                key: ValueKey(f.id),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  color: kRed,
                  child: const Icon(Icons.delete_outline),
                ),
                onDismissed: (_) => _removeFriend(f),
                child: _FriendTile(
                  friend: f,
                  nearby: radar.isNearby(f),
                  onTap: Cloud.configured
                      ? () => Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) =>
                                ChatScreen(friend: f, cloud: cloud),
                          ))
                      : null,
                ),
              ),
            if (store.friends.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text('Glisse vers la gauche pour retirer un pote.',
                    style: text.bodySmall?.copyWith(color: Colors.white38)),
              ),
            Padding(
              padding: const EdgeInsets.only(top: 32),
              child: Text('Festipote · version $appBuild',
                  textAlign: TextAlign.center,
                  style: text.bodySmall?.copyWith(color: Colors.white24)),
            ),
          ],
        ),
      ),
    );
  }
}

class _RadarCard extends StatelessWidget {
  const _RadarCard({required this.radar});

  final Radar radar;

  @override
  Widget build(BuildContext context) {
    final on = radar.active;
    final text = Theme.of(context).textTheme;
    final nearbyCount = radar.store.friends.where(radar.isNearby).length;

    final String subtitle;
    if (!on) {
      subtitle = 'Active-le en arrivant sur le site. Tu peux ensuite '
          'verrouiller ton téléphone.';
    } else if (nearbyCount > 0) {
      subtitle = nearbyCount == 1
          ? '1 pote dans le coin'
          : '$nearbyCount potes dans le coin';
    } else {
      subtitle = 'Ton téléphone vibrera quand un pote passe près de toi.';
    }

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: on ? kRed.withValues(alpha: 0.18) : Colors.white10,
        border: Border.all(color: on ? kRed : Colors.white24, width: 2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Icon(on ? Icons.radar : Icons.bluetooth_disabled,
              size: 64, color: on ? kRed : Colors.white38),
          const SizedBox(height: 12),
          Text(on ? 'Mode festival activé' : 'Mode festival désactivé',
              style: text.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(subtitle, textAlign: TextAlign.center),
          if (radar.error != null) ...[
            const SizedBox(height: 10),
            Text(radar.error!,
                textAlign: TextAlign.center,
                style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
          const SizedBox(height: 18),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: on ? Colors.white : kRed,
              foregroundColor: on ? Colors.black : Colors.white,
              minimumSize: const Size(200, 52),
            ),
            onPressed: radar.starting ? null : radar.toggle,
            icon: Icon(on ? Icons.stop : Icons.play_arrow),
            label: Text(radar.starting
                ? 'Démarrage…'
                : on
                    ? 'Arrêter'
                    : 'Activer le mode festival'),
          ),
        ],
      ),
    );
  }
}

class _FriendTile extends StatelessWidget {
  const _FriendTile({required this.friend, required this.nearby, this.onTap});

  final Friend friend;
  final bool nearby;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final seen = friend.lastSeen;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 4),
      leading: CircleAvatar(
        backgroundColor: nearby ? kRed : Colors.white12,
        foregroundColor: Colors.white,
        child: Text(friend.name.characters.first.toUpperCase()),
      ),
      title: Text(friend.name),
      subtitle: Text(nearby
          ? 'Dans le coin en ce moment'
          : seen == null
              ? 'Pas encore croisé·e'
              : 'Croisé·e ${formatSeen(seen)}'),
      trailing: onTap == null
          ? null
          : const Icon(Icons.chat_bubble_outline, color: Colors.white54),
      onTap: onTap,
    );
  }
}

// ---------------------------------------------------------------------------
// Mon QR code
// ---------------------------------------------------------------------------

class MyQrScreen extends StatelessWidget {
  const MyQrScreen({super.key, required this.store});

  final Store store;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mon QR code')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: QrImageView(
                  data: store.myQrPayload,
                  version: QrVersions.auto,
                  size: 240,
                  backgroundColor: Colors.white,
                ),
              ),
              const SizedBox(height: 20),
              Text(store.myName ?? '',
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text(
                'Fais scanner ce code à tes potes pour qu\'iels puissent te capter.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 28),
              OutlinedButton.icon(
                icon: const Icon(Icons.copy),
                label: const Text('Copier mon code pour l\'envoyer'),
                onPressed: () async {
                  await Clipboard.setData(
                      ClipboardData(text: store.myShareText));
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text(
                        'Code copié ! Colle-le dans un message à ton pote.'),
                  ));
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Scanner le QR code d'un pote
// ---------------------------------------------------------------------------

enum _CamState { checking, ready, denied }

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  bool _done = false;
  late _CamState _cam;

  @override
  void initState() {
    super.initState();
    // Sur iPhone, le scanner demande l'accès à la caméra lui-même.
    _cam = Platform.isAndroid ? _CamState.checking : _CamState.ready;
    if (Platform.isAndroid) _askCamera();
  }

  Future<void> _askCamera() async {
    final status = await Permission.camera.request();
    if (!mounted) return;
    setState(() => _cam = status.isGranted ? _CamState.ready : _CamState.denied);
  }

  void _finish(Friend friend) {
    if (_done) return;
    _done = true;
    Navigator.of(context).pop(friend);
  }

  void _onDetect(BarcodeCapture capture) {
    for (final barcode in capture.barcodes) {
      final raw = barcode.rawValue;
      if (raw == null) continue;
      final friend = Store.parseCode(raw);
      if (friend != null) {
        _finish(friend);
        return;
      }
    }
  }

  Future<void> _pasteCode() async {
    final clip = await Clipboard.getData(Clipboard.kTextPlain);
    if (!mounted) return;
    final clipText = clip?.text ?? '';
    final ctrl = TextEditingController(
        text: Store.parseCode(clipText) != null ? clipText : '');
    final text = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Coller le code d\'un pote'),
        content: TextField(
          controller: ctrl,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'festipote:…',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, ctrl.text),
            child: const Text('Ajouter'),
          ),
        ],
      ),
    );
    if (text == null || !mounted) return;
    final friend = Store.parseCode(text);
    if (friend == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Ce n\'est pas un code Festipote valide'),
      ));
      return;
    }
    _finish(friend);
  }

  Widget _camera() {
    return switch (_cam) {
      _CamState.checking => const Center(child: CircularProgressIndicator()),
      _CamState.denied => const _CameraProblem(
          message: 'Festipote n\'a pas accès à la caméra.',
          action: FilledButton(
            onPressed: openAppSettings,
            child: Text('Ouvrir les réglages'),
          ),
        ),
      _CamState.ready => MobileScanner(
          onDetect: _onDetect,
          errorBuilder: (context, error, child) => _CameraProblem(
            message: 'La caméra n\'a pas pu démarrer.\n'
                '(${error.errorCode.name}'
                '${error.errorDetails?.message != null ? ' : ${error.errorDetails!.message}' : ''})',
          ),
        ),
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ajouter un pote')),
      body: Column(
        children: [
          Expanded(child: ClipRect(child: _camera())),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'Vise le QR code Festipote de ton pote',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _pasteCode,
                    icon: const Icon(Icons.content_paste),
                    label: const Text('Coller un code reçu par message'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CameraProblem extends StatelessWidget {
  const _CameraProblem({required this.message, this.action});

  final String message;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.videocam_off, size: 48, color: Colors.white54),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 8),
            const Text(
              'Tu peux aussi coller le code que ton pote t\'a envoyé.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60),
            ),
            if (action != null) ...[
              const SizedBox(height: 16),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}
