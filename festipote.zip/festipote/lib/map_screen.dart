import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import 'cloud.dart';
import 'main.dart' show kRed;
import 'store.dart';

/// Les positions plus vieilles que ça ne sont plus affichées.
const _maxAge = Duration(hours: 1);

class MapScreen extends StatefulWidget {
  const MapScreen({super.key, required this.store, required this.cloud});

  final Store store;
  final Cloud cloud;

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final _map = MapController();

  @override
  void initState() {
    super.initState();
    _locate();
  }

  Future<void> _locate() async {
    final err = await widget.cloud.locateMe();
    if (!mounted) return;
    if (err != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
    }
    final p = widget.cloud.myPosition;
    if (p != null) {
      try {
        _map.move(LatLng(p.latitude, p.longitude), 17);
      } catch (_) {}
    }
  }

  Future<void> _toggleSharing(bool on) async {
    String? err;
    if (on) {
      err = await widget.cloud.startSharing();
    } else {
      await widget.cloud.stopSharing();
    }
    if (err != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
    }
  }

  List<Friend> _visibleFriends() {
    final now = DateTime.now();
    return widget.store.friends
        .where((f) =>
            f.lat != null &&
            f.lon != null &&
            f.locationAt != null &&
            now.difference(f.locationAt!) < _maxAge)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.cloud,
      builder: (context, _) {
        final cloud = widget.cloud;
        final me = cloud.myPosition;
        final friends = _visibleFriends();
        final LatLng start = me != null
            ? LatLng(me.latitude, me.longitude)
            : friends.isNotEmpty
                ? LatLng(friends.first.lat!, friends.first.lon!)
                : const LatLng(46.6, 2.4); // centre de la France

        return Scaffold(
          appBar: AppBar(title: const Text('Carte')),
          body: Stack(
            children: [
              FlutterMap(
                mapController: _map,
                options: MapOptions(
                  initialCenter: start,
                  initialZoom: me != null || friends.isNotEmpty ? 16 : 5,
                ),
                children: [
                  TileLayer(
                    urlTemplate:
                        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'fr.festipote.festipote',
                  ),
                  MarkerLayer(
                    markers: [
                      for (final f in friends)
                        Marker(
                          point: LatLng(f.lat!, f.lon!),
                          width: 150,
                          height: 60,
                          alignment: Alignment.topCenter,
                          child: _FriendPin(friend: f),
                        ),
                      if (me != null)
                        Marker(
                          point: LatLng(me.latitude, me.longitude),
                          width: 22,
                          height: 22,
                          child: const _MeDot(),
                        ),
                    ],
                  ),
                  SimpleAttributionWidget(
                    source: const Text('OpenStreetMap'),
                  ),
                ],
              ),
              Positioned(
                top: 12,
                right: 12,
                child: FloatingActionButton.small(
                  heroTag: 'locate',
                  onPressed: _locate,
                  child: const Icon(Icons.my_location),
                ),
              ),
              Positioned(
                left: 12,
                right: 12,
                bottom: 36,
                child: _SharingCard(
                  cloud: cloud,
                  visibleCount: friends.length,
                  onChanged: _toggleSharing,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SharingCard extends StatelessWidget {
  const _SharingCard({
    required this.cloud,
    required this.visibleCount,
    required this.onChanged,
  });

  final Cloud cloud;
  final int visibleCount;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    if (!Cloud.configured) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(14),
          child: Text(
            'Serveur non configuré : tu vois ta position, mais pas celle de '
            'tes potes. Voir le README pour activer la carte.',
          ),
        ),
      );
    }
    final String subtitle;
    if (!cloud.online) {
      subtitle = 'Pas de réseau pour l\'instant, nouvel essai en cours…';
    } else if (visibleCount == 0) {
      subtitle = 'Aucun pote ne partage sa position en ce moment.';
    } else {
      subtitle = visibleCount == 1
          ? '1 pote visible sur la carte'
          : '$visibleCount potes visibles sur la carte';
    }
    return Card(
      child: SwitchListTile(
        title: const Text('Partager ma position'),
        subtitle: Text(subtitle),
        value: cloud.sharing,
        onChanged: onChanged,
      ),
    );
  }
}

class _FriendPin extends StatelessWidget {
  const _FriendPin({required this.friend});

  final Friend friend;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: kRed,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            '${friend.name} · ${timeAgo(friend.locationAt!)}',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        const Icon(Icons.location_on, color: kRed, size: 30),
      ],
    );
  }
}

class _MeDot extends StatelessWidget {
  const _MeDot();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.lightBlueAccent,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 3),
      ),
    );
  }
}
