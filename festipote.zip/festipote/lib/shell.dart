import 'package:flutter/material.dart';

import 'chat_screens.dart';
import 'cloud.dart';
import 'map_screen.dart';
import 'radar.dart';
import 'screens.dart';
import 'stats_screen.dart';
import 'store.dart';

/// Écran principal avec les onglets Radar / Carte / Chat / Stats.
class Shell extends StatefulWidget {
  const Shell({
    super.key,
    required this.store,
    required this.radar,
    required this.cloud,
  });

  final Store store;
  final Radar radar;
  final Cloud cloud;

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;
  // La carte n'est chargée qu'au premier passage sur l'onglet.
  bool _mapOpened = false;

  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    final radar = widget.radar;
    final cloud = widget.cloud;
    return Scaffold(
      body: IndexedStack(
        index: _tab,
        children: [
          HomeScreen(store: store, radar: radar, cloud: cloud),
          _mapOpened
              ? MapScreen(store: store, cloud: cloud)
              : const SizedBox.shrink(),
          ChatListScreen(store: store, cloud: cloud),
          StatsScreen(store: store, radar: radar),
        ],
      ),
      bottomNavigationBar: ListenableBuilder(
        listenable: cloud,
        builder: (context, _) {
          final unread = cloud.totalUnread;
          return NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() {
              _tab = i;
              if (i == 1) _mapOpened = true;
            }),
            destinations: [
              const NavigationDestination(
                icon: Icon(Icons.radar),
                label: 'Radar',
              ),
              const NavigationDestination(
                icon: Icon(Icons.map_outlined),
                selectedIcon: Icon(Icons.map),
                label: 'Carte',
              ),
              NavigationDestination(
                icon: Badge(
                  isLabelVisible: unread > 0,
                  label: Text('$unread'),
                  child: const Icon(Icons.chat_bubble_outline),
                ),
                selectedIcon: Badge(
                  isLabelVisible: unread > 0,
                  label: Text('$unread'),
                  child: const Icon(Icons.chat_bubble),
                ),
                label: 'Chat',
              ),
              const NavigationDestination(
                icon: Icon(Icons.bar_chart),
                label: 'Stats',
              ),
            ],
          );
        },
      ),
    );
  }
}
