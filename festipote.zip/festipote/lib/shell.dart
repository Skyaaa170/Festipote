import 'package:flutter/material.dart';

import 'chat_screens.dart';
import 'cloud.dart';
import 'duel_screens.dart';
import 'map_screen.dart';
import 'radar.dart';
import 'screens.dart';
import 'stats_screen.dart';
import 'store.dart';

/// Écran principal : Radar / Carte / Duels / Chat / Stats.
class Shell extends StatefulWidget {
  const Shell({
    super.key,
    required this.store,
    required this.radar,
    required this.cloud,
  });

  final Store store;
  final Radar radar;
  final Cloud cloud;

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;
  bool _mapOpened = false; // la carte n'est chargée qu'au premier passage
  final Set<int> _shownDuels = {};
  bool _duelOnScreen = false;

  @override
  void initState() {
    super.initState();
    widget.cloud.addListener(_maybeShowDuel);
  }

  @override
  void dispose() {
    widget.cloud.removeListener(_maybeShowDuel);
    super.dispose();
  }

  /// Dès qu'un duel commence, on affiche le gros bouton.
  /// (Si l'appli est en arrière-plan, il s'affichera à l'ouverture.)
  void _maybeShowDuel() {
    final d = widget.cloud.pendingDuel;
    if (d == null || _duelOnScreen || _shownDuels.contains(d.id)) return;
    _shownDuels.add(d.id);
    _duelOnScreen = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) {
        _duelOnScreen = false;
        return;
      }
      await Navigator.of(context).push(MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => DuelScreen(cloud: widget.cloud, duelId: d.id),
      ));
      _duelOnScreen = false;
    });
    WidgetsBinding.instance.scheduleFrame();
  }

  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    final radar = widget.radar;
    final cloud = widget.cloud;
    return Scaffold(
      body: IndexedStack(
        index: _tab,
        children: [
          HomeScreen(store: store, radar: radar, cloud: cloud),
          _mapOpened
              ? MapScreen(store: store, cloud: cloud)
              : const SizedBox.shrink(),
          DuelsTab(store: store, cloud: cloud),
          ChatListScreen(store: store, cloud: cloud),
          StatsScreen(store: store, radar: radar, cloud: cloud),
        ],
      ),
      bottomNavigationBar: ListenableBuilder(
        listenable: cloud,
        builder: (context, _) {
          final unread = cloud.totalUnread;
          final duelLive = cloud.pendingDuel != null;
          return NavigationBar(
            selectedIndex: _tab,
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            onDestinationSelected: (i) {
              setState(() {
                _tab = i;
                if (i == 1) _mapOpened = true;
              });
              if (i == 2) {
                cloud.refreshLeaderboard();
                cloud.refreshEventBoard();
              }
            },
            destinations: [
              const NavigationDestination(
                icon: Icon(Icons.radar),
                label: 'Radar',
              ),
              const NavigationDestination(
                icon: Icon(Icons.map_outlined),
                selectedIcon: Icon(Icons.map),
                label: 'Carte',
              ),
              NavigationDestination(
                icon: Badge(
                  isLabelVisible: duelLive,
                  label: const Text('!'),
                  child: const Icon(Icons.emoji_events_outlined),
                ),
                selectedIcon: const Icon(Icons.emoji_events),
                label: 'Duels',
              ),
              NavigationDestination(
                icon: Badge(
                  isLabelVisible: unread > 0,
                  label: Text('$unread'),
                  child: const Icon(Icons.chat_bubble_outline),
                ),
                selectedIcon: Badge(
                  isLabelVisible: unread > 0,
                  label: Text('$unread'),
                  child: const Icon(Icons.chat_bubble),
                ),
                label: 'Chat',
              ),
              const NavigationDestination(
                icon: Icon(Icons.bar_chart),
                label: 'Stats',
              ),
            ],
          );
        },
      ),
    );
  }
}
