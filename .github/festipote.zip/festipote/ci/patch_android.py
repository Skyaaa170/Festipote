"""Réglages Android appliqués après `flutter create` (lancé par GitHub Actions)."""
import base64
import json
import pathlib
import re

SDK = 36

# --- Permissions Bluetooth, caméra, notifications ---------------------------
m = pathlib.Path('android/app/src/main/AndroidManifest.xml')
s = m.read_text()
perms = '''<uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-feature android:name="android.hardware.bluetooth_le" android:required="true" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    '''
if 'BLUETOOTH_SCAN' not in s:
    s = s.replace('<application', perms + '<application', 1)
    s = s.replace('android:label="festipote"', 'android:label="Festipote"', 1)
    m.write_text(s)

# --- build.gradle de l'appli -------------------------------------------------
kts = pathlib.Path('android/app/build.gradle.kts')
is_kts = kts.exists()
g = kts if is_kts else pathlib.Path('android/app/build.gradle')
s = g.read_text()

if is_kts:
    desugar_flag = 'isCoreLibraryDesugaringEnabled = true'
    desugar_dep = 'coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")'
    no_r8 = 'release {\n            isMinifyEnabled = false\n            isShrinkResources = false\n        }'
    s = s.replace('compileSdk = flutter.compileSdkVersion',
                  f'compileSdk = maxOf(flutter.compileSdkVersion, {SDK})')
else:
    desugar_flag = 'coreLibraryDesugaringEnabled true'
    desugar_dep = "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'"
    no_r8 = 'release {\n            minifyEnabled false\n            shrinkResources false\n        }'
    s = re.sub(r'compileSdk(?:Version)? flutter\.compileSdkVersion',
               f'compileSdk Math.max(flutter.compileSdkVersion, {SDK})', s)

# Desugaring (demandé par flutter_local_notifications)
if 'DesugaringEnabled' not in s:
    if 'compileOptions {' in s:
        s = s.replace('compileOptions {', 'compileOptions {\n        ' + desugar_flag, 1)
    else:
        s = s.replace('android {', 'android {\n    compileOptions {\n        ' + desugar_flag + '\n    }', 1)
    s += '\ndependencies {\n    ' + desugar_dep + '\n}\n'

# Pas de R8 : il casse souvent la caméra / ML Kit dans les APK finaux
if 'MinifyEnabled = false' not in s and 'minifyEnabled false' not in s:
    if 'buildTypes {' in s:
        s = s.replace('buildTypes {', 'buildTypes {\n        ' + no_r8, 1)
    else:
        s = s.replace('android {', 'android {\n    buildTypes {\n        ' + no_r8 + '\n    }', 1)

g.write_text(s)
print('Réglages Android OK')
print('\n'.join(l for l in s.splitlines() if re.search(r'compileSdk|inify|hrink|esugar', l)))

# --- Serveur Supabase (carte + chat) ----------------------------------------
# On lit supabase.txt (ou .json) à la racine du dépôt, en étant tolérant :
# il suffit que l'URL du projet et la clé publique soient dedans.
cfg_text = None
for name in ['../supabase.txt', '../supabase.json', 'supabase.txt', 'supabase.json']:
    path = pathlib.Path(name)
    if path.exists():
        cfg_text = path.read_text(errors='ignore')
        break

config = pathlib.Path('lib/config.dart')
if cfg_text is None:
    print('::notice::Pas de supabase.txt : carte et chat désactivés dans cet APK.')
else:
    url = re.search(r'https://[A-Za-z0-9-]+\.supabase\.co', cfg_text)
    key = re.search(r'sb_publishable_[A-Za-z0-9_-]+|eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+', cfg_text)
    secret = 'sb_secret_' in cfg_text
    if key and key.group(0).startswith('eyJ'):
        try:
            part = key.group(0).split('.')[1]
            payload = json.loads(base64.urlsafe_b64decode(part + '=' * (-len(part) % 4)))
            secret = secret or payload.get('role') == 'service_role'
        except Exception:
            pass
    if secret:
        print('::error::supabase.txt contient une clé SECRÈTE (service_role / sb_secret). '
              'Mets la clé publique (anon / publishable) à la place, et change la clé secrète dans Supabase.')
        raise SystemExit(1)
    if not url or not key:
        print('::error::supabase.txt : URL (https://xxx.supabase.co) ou clé publique introuvable.')
        raise SystemExit(1)
    def dart(v):
        return json.dumps(v).replace('$', '\\$')
    config.write_text(
        '// Généré à la compilation depuis supabase.txt\n'
        f'const supabaseUrl = {dart(url.group(0))};\n'
        f'const supabaseKey = {dart(key.group(0))};\n')
    print('Serveur configuré :', url.group(0))
